# Wezesha voice control: Chrome extension

Adds the voice plugin to every website. Build it from `apps/voice-nav`:

```sh
npm run build:extension      # → dist/extension (unpacked) and dist/site/wezesha-extension.zip
```

Install for testing: unzip, open `chrome://extensions`, turn on Developer mode, "Load unpacked", pick the folder.
The toolbar button turns it off or on for the site you are on.

Known limits of this first version:
- Models are cached per site, so the first visit to each site downloads them (~50 MB) again.
  Next step: host the models once in the extension's offscreen document and share them across sites.
- Sites with a strict Content Security Policy block the model download. Tested 2026-10-21:
  example.com loads the models and runs commands; on Wikipedia the panel, reading, headings and fixed
  commands work, but the models can't load ("Failed to fetch": the page may only fetch from itself).
  Same next step fixes this: run the models in the extension's offscreen document, which the page's
  policy doesn't cover, and pass audio and text to it by message.
