// The toolbar button turns Wezesha off or on for the current site.
async function badge(tabId, url) {
  if (!url || !/^https?:/.test(url)) return;
  const { off = [] } = await chrome.storage.local.get('off');
  const isOff = off.includes(new URL(url).hostname);
  await chrome.action.setBadgeText({ tabId, text: isOff ? 'off' : '' });
  await chrome.action.setBadgeBackgroundColor({ tabId, color: '#8f72e8' });
  await chrome.action.setTitle({ tabId, title: isOff ? 'Wezesha is off for this site. Click to turn it on.' : 'Wezesha is on. Click to turn it off for this site.' });
}
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url || !/^https?:/.test(tab.url)) return;
  const host = new URL(tab.url).hostname;
  const { off = [] } = await chrome.storage.local.get('off');
  const next = off.includes(host) ? off.filter((h) => h !== host) : [...off, host];
  await chrome.storage.local.set({ off: next });
  await badge(tab.id, tab.url);
  chrome.tabs.reload(tab.id);
});
chrome.tabs.onUpdated.addListener((tabId, info, tab) => { if (info.status === 'complete') badge(tabId, tab.url); });
