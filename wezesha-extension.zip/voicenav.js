var at = Object.defineProperty;
var Ie = (s) => {
  throw TypeError(s);
};
var ct = (s, e, t) => e in s ? at(s, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : s[e] = t;
var M = (s, e, t) => ct(s, typeof e != "symbol" ? e + "" : e, t), we = (s, e, t) => e.has(s) || Ie("Cannot " + t);
var k = (s, e, t) => (we(s, e, "read from private field"), t ? t.call(s) : e.get(s)), L = (s, e, t) => e.has(s) ? Ie("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(s) : e.set(s, t), C = (s, e, t, i) => (we(s, e, "write to private field"), i ? i.call(s, t) : e.set(s, t), t), S = (s, e, t) => (we(s, e, "access private method"), t);
var Ce = (s, e, t, i) => ({
  set _(n) {
    C(s, e, n, t);
  },
  get _() {
    return k(s, e, i);
  }
});
var p = class extends Error {
  constructor(e, t, i) {
    super(t, i);
    M(this, "code");
    M(this, "name", "NeedleError");
    this.code = e;
  }
}, lt = class extends p {
  constructor(e = "The model returned values that are not grounded in the input.") {
    super("INVALID_RESPONSE", e);
    M(this, "name", "ExtractionValidationError");
  }
};
function ge(s) {
  return s instanceof Error ? s.message : String(s);
}
function G(s, e) {
  if (typeof s != "string" || s.includes("\0")) throw new p("INVALID_ARGUMENT", `${e} must be a string without null bytes.`);
}
function be(s, e, t, i) {
  if (!Number.isSafeInteger(s) || s < t || s > i) throw new p("INVALID_ARGUMENT", `${e} must be an integer between ${t} and ${i}.`);
  return s;
}
const Je = /* @__PURE__ */ new WeakMap();
async function Me(s, e) {
  const t = Je.get(s);
  if (t && (await t(e)).issues) throw new p("INVALID_ARGUMENT", "Tool input failed schema validation.");
}
function ht(s) {
  var n;
  let e = s.inputSchema, t;
  if (!e || typeof e != "object") throw new p("INVALID_ARGUMENT", "inputSchema must be an object schema.");
  if ("~standard" in e) {
    const o = e["~standard"];
    if ((o == null ? void 0 : o.version) !== 1 || typeof ((n = o.jsonSchema) == null ? void 0 : n.input) != "function") throw new p("INVALID_ARGUMENT", "Use a Standard JSON Schema library (such as Zod 4.2+) or a plain JSON Schema.");
    try {
      e = o.jsonSchema.input({ target: "draft-07" }), o.validate && (t = o.validate.bind(o));
    } catch (a) {
      throw new p("INVALID_ARGUMENT", `Cannot convert inputSchema: ${ge(a)}`, { cause: a });
    }
  }
  if (e.type !== "object") throw new p("INVALID_ARGUMENT", "A tool inputSchema must describe an object.");
  if (s.execute !== void 0 && typeof s.execute != "function") throw new p("INVALID_ARGUMENT", "execute must be a function.");
  const i = Object.freeze({
    inputSchema: e,
    ...s.description === void 0 ? {} : { description: s.description },
    ...s.triggers === void 0 ? {} : { triggers: s.triggers },
    ...s.execute === void 0 ? {} : { execute: s.execute }
  });
  return t && Je.set(i, t), i;
}
function dt(s) {
  if (Array.isArray(s)) return s;
  if (!s || typeof s != "object") throw new p("INVALID_ARGUMENT", "tools must be a named tool object or an array of schemas.");
  return Object.entries(s).map(([e, t]) => {
    if (!t || typeof t != "object" || !t.inputSchema) throw new p("INVALID_ARGUMENT", `Tool ${e} needs inputSchema. Use tool({ inputSchema, description }).`);
    return {
      name: e,
      parameters: t.inputSchema,
      ...t.description === void 0 ? {} : { description: t.description },
      ...t.triggers === void 0 ? {} : { triggers: t.triggers }
    };
  });
}
var ut = "Cactus-Compute/needle3", Re = "2ae11323dc000f5e70c49f7403efa6af12ba9e67", q = {
  repository: "Cactus-Compute/whistle",
  revision: "b358ddadd89b7a713b5aa131f23032d3cca1b251",
  path: "whistle.cact",
  size: 16919407,
  sha256: "b6e02f048568ac5d01a2042556c658061e699acbc0aa2a1439f52f3d461dffeb"
}, ye = {
  path: "needle3.cact",
  size: 35335380,
  sha256: "c9d915eca282ed42d1a09b143b592adb4cc6744ffe2d294adf5cfc5548170c38"
};
const pt = Object.freeze({
  name: "needle3",
  revision: Re,
  size: ye.size,
  sha256: ye.sha256,
  url: `https://huggingface.co/${ut}/resolve/${Re}/${ye.path}`
}), ft = Object.freeze({
  name: "whistle",
  revision: q.revision,
  size: q.size,
  sha256: q.sha256,
  url: `https://huggingface.co/${q.repository}/resolve/${q.revision}/${q.path}`
});
function Qe(s) {
  const e = s.system ?? "";
  if (G(e, "system"), s.stateless !== void 0 && typeof s.stateless != "boolean") throw new p("INVALID_ARGUMENT", "stateless must be a boolean.");
  return {
    system: e,
    toolsJson: Xe(s.tools ?? []),
    stateless: s.stateless ?? !1,
    bufferSize: be(s.bufferSize ?? 262144, "bufferSize", 1024, 16777216)
  };
}
function Xe(s) {
  const e = dt(s), t = /* @__PURE__ */ new Set();
  for (const i of e) {
    if (!i || typeof i != "object") throw new p("INVALID_ARGUMENT", "Each tool must be a schema object.");
    const n = i && "type" in i && i.type === "function" ? i.function : i;
    if (!n || typeof n != "object" || !("name" in n)) throw new p("INVALID_ARGUMENT", "Each tool must be a schema object.");
    if (G(n.name, "Tool name"), !n.name.trim() || t.has(n.name)) throw new p("INVALID_ARGUMENT", "Tool names must be nonempty and unique.");
    if (!n.parameters || typeof n.parameters != "object" || Array.isArray(n.parameters)) throw new p("INVALID_ARGUMENT", `Tool ${n.name} must have a parameters schema.`);
    t.add(n.name);
  }
  try {
    return JSON.stringify(e, (i, n) => {
      if (typeof n == "function" || typeof n == "symbol" || typeof n == "number" && !Number.isFinite(n)) throw new Error("Tool definitions must contain JSON values.");
      return n;
    });
  } catch (i) {
    throw new p("INVALID_ARGUMENT", `Tools must be JSON-serializable: ${ge(i)}`, { cause: i });
  }
}
var z, V, se, Y, Ge, Ye = (Ge = class {
  constructor(s) {
    M(this, "load");
    L(this, z, new AbortController());
    L(this, V);
    L(this, se, Promise.resolve());
    L(this, Y);
    this.load = s;
  }
  assertOpen() {
    k(this, z).signal.throwIfAborted();
  }
  use(s, e) {
    if (e != null && e.aborted) return Promise.reject(e.reason);
    if (k(this, z).signal.aborted) return Promise.reject(k(this, z).signal.reason);
    const t = () => {
      this.close();
    };
    e == null || e.addEventListener("abort", t, { once: !0 });
    const i = k(this, z).signal;
    let n;
    const o = new Promise((c, h) => {
      n = h;
    }), a = () => n(e != null && e.aborted ? e.reason : i.reason);
    i.addEventListener("abort", a, { once: !0 });
    const r = k(this, se).then(async () => {
      i.throwIfAborted(), k(this, V) || C(this, V, this.load(i).catch((d) => {
        throw C(this, V, void 0), d;
      }));
      const c = await k(this, V);
      i.throwIfAborted();
      const h = await s(c, i);
      return i.throwIfAborted(), h;
    });
    return C(this, se, r.catch(() => {
    })), Promise.race([r, o]).finally(() => {
      e == null || e.removeEventListener("abort", t), i.removeEventListener("abort", a);
    });
  }
  /** Eager factories return a ready model or dispose of a failed initialization. */
  async ready(s) {
    try {
      return await this.use(async () => {
      }, s), this;
    } catch (e) {
      throw await this.close(), e;
    }
  }
  close() {
    var s;
    return k(this, Y) || (k(this, z).abort(new p("CLOSED", "This model session was closed.")), C(this, Y, ((s = k(this, V)) == null ? void 0 : s.then((e) => e.close(), () => {
    })) ?? Promise.resolve())), k(this, Y);
  }
  [Symbol.asyncDispose]() {
    return this.close();
  }
}, z = new WeakMap(), V = new WeakMap(), se = new WeakMap(), Y = new WeakMap(), Ge);
function Oe(s) {
  if (s !== void 0 && typeof s != "boolean") throw new p("INVALID_ARGUMENT", "strict must be a boolean.");
  return s ?? !0;
}
function ke(s) {
  if (!s.success) throw new p("ENGINE_ERROR", s.error ?? "Generation failed.");
}
var mt = class extends Ye {
  constructor(e, t) {
    super(e);
    M(this, "options");
    this.options = t, Qe(t);
  }
  generate(e) {
    return this.use(async (t) => (this.options.stateless && await t.reset(), t.generate(e)), e.abortSignal);
  }
  complete(e = "", t) {
    return this.use(async (i) => (this.options.stateless && await i.reset(), i.complete(e, t)), t == null ? void 0 : t.abortSignal);
  }
  embed(e = "", t) {
    return this.use((i) => i.embed(e), t == null ? void 0 : t.abortSignal);
  }
  reset() {
    return this.use((e) => e.reset());
  }
  async run(e = "", t = {}) {
    G(e, "query");
    const i = be(t.maxSteps ?? 8, "maxSteps", 1, 32), n = Oe(t.strict), o = t.maxNewTokens === void 0 ? {} : { maxNewTokens: t.maxNewTokens };
    return this.use(async (a, r) => {
      var d, l, f;
      this.options.stateless && await a.reset();
      let c = await a.complete(e, o);
      const h = [];
      for (let g = 0; g < i && (ke(c), !(c.type !== "call" || !c.function_calls.length)); g++) {
        const m = [];
        for (const v of c.function_calls) {
          r.throwIfAborted();
          const y = (l = (d = c.validation) == null ? void 0 : d.ungrounded) == null ? void 0 : l.some((w) => w === v.name || w.startsWith(`${v.name}.`));
          if (n && (y || (f = c.validation) != null && f.negation)) {
            m.push({ error: "The model flagged this call as ungrounded." });
            continue;
          }
          const b = this.options.tools, u = b && !Array.isArray(b) && Object.hasOwn(b, v.name) ? b[v.name] : void 0;
          if (!(u != null && u.execute)) {
            m.push({ error: `No execute function registered for ${v.name}.` });
            continue;
          }
          try {
            await Me(u, v.arguments), r.throwIfAborted();
            const w = await u.execute(v.arguments, { abortSignal: r });
            m.push(JSON.parse(JSON.stringify(w ?? null, ($, E) => typeof E == "bigint" ? String(E) : E)));
          } catch (w) {
            r.throwIfAborted(), m.push({ error: ge(w) });
          }
        }
        h.push(...m), r.throwIfAborted(), c = await a.complete(JSON.stringify(m), o);
      }
      return ke(c), {
        ...c,
        results: h
      };
    }, t.abortSignal);
  }
  async extract(e, t, i = {}) {
    G(e, "text");
    const n = Oe(i.strict), o = ht({ inputSchema: t });
    return this.use(async (a) => {
      var h, d, l;
      await a.reset();
      const r = await a.complete(e, {
        tools: { extract: o },
        ...i.maxNewTokens === void 0 ? {} : { maxNewTokens: i.maxNewTokens }
      });
      if (ke(r), n && ((d = (h = r.validation) == null ? void 0 : h.ungrounded) != null && d.length || (l = r.validation) != null && l.negation)) throw new lt();
      const c = r.function_calls.find((f) => f.name === "extract");
      return c ? (await Me(o, c.arguments), c.arguments) : null;
    }, i.abortSignal);
  }
};
const Ue = [
  "en",
  "de",
  "fr",
  "es",
  "it",
  "nl",
  "pl"
];
function re(s) {
  throw new p("INVALID_ARGUMENT", s);
}
function Te(s) {
  const { language: e, keywords: t, wordTimestamps: i } = s;
  if (e !== void 0 && !Ue.includes(e) && re(`language must be one of ${Ue.join(", ")}.`), i !== void 0 && typeof i != "boolean" && re("wordTimestamps must be a boolean."), t !== void 0) {
    (!Array.isArray(t) || t.length > 100) && re("keywords must be an array of at most 100 phrases.");
    for (const n of t)
      G(n, "keyword"), (!n.trim() || n.length > 256 || /[\r\n]/.test(n)) && re("Each keyword must be a nonempty phrase of at most 256 characters without newlines.");
  }
  return {
    ...e === void 0 ? {} : { language: e },
    ...t === void 0 ? {} : { keywords: [...t] },
    ...i === void 0 ? {} : { wordTimestamps: i }
  };
}
var H, Z, he, qe, gt = (qe = class extends Ye {
  constructor(e, t) {
    super(e);
    L(this, Z);
    M(this, "read");
    L(this, H);
    this.read = t;
  }
  async transcribe(e, t = {}) {
    var n;
    (n = t.abortSignal) == null || n.throwIfAborted(), S(this, Z, he).call(this);
    const i = Te(t);
    return this.use(async (o, a) => {
      const r = await this.read(e, a);
      return a.throwIfAborted(), o.transcribe(r, i);
    }, t.abortSignal);
  }
  async embed(e, t = {}) {
    var i;
    return (i = t.abortSignal) == null || i.throwIfAborted(), S(this, Z, he).call(this), this.use(async (n, o) => {
      const a = await this.read(e, o);
      return o.throwIfAborted(), n.embedAudio(a);
    }, t.abortSignal);
  }
  async *stream(e, t = {}) {
    var g, m, v;
    (g = t.abortSignal) == null || g.throwIfAborted(), S(this, Z, he).call(this);
    const i = Te(t), n = new AbortController();
    C(this, H, n);
    const o = t.abortSignal ? AbortSignal.any([n.signal, t.abortSignal]) : n.signal, a = () => {
      this.close();
    };
    (m = t.abortSignal) == null || m.addEventListener("abort", a, { once: !0 });
    let r;
    const c = new Promise((y, b) => {
      r = b;
    });
    c.catch(() => {
    });
    const h = () => {
      var y;
      return r((y = t.abortSignal) != null && y.aborted ? t.abortSignal.reason : o.reason);
    };
    o.addEventListener("abort", h, { once: !0 });
    let d, l = !1, f = !1;
    try {
      for (d = (Symbol.asyncIterator in e) ? e[Symbol.asyncIterator]() : e[Symbol.iterator](); ; ) {
        o.throwIfAborted();
        const y = await Promise.race([d.next(), c]);
        if (y.done) break;
        l = !0, yield await this.use((b) => b.streamTranscribe(y.value, i), o);
      }
      if (l) {
        const y = await this.use((b) => b.streamTranscribe(void 0, i), o);
        f = !0, yield y;
      }
    } finally {
      if ((v = t.abortSignal) == null || v.removeEventListener("abort", a), o.removeEventListener("abort", h), l && !f && !o.aborted) try {
        await this.use((y) => y.streamTranscribe(void 0, i));
      } catch {
        await this.close();
      }
      if (C(this, H, void 0), d != null && d.return) {
        const y = Promise.resolve().then(() => {
          var b;
          return (b = d == null ? void 0 : d.return) == null ? void 0 : b.call(d);
        });
        o.aborted ? y.catch(() => {
        }) : await y;
      }
    }
  }
  close() {
    var e;
    return (e = k(this, H)) == null || e.abort(new p("CLOSED", "This transcription stream was closed.")), super.close();
  }
}, H = new WeakMap(), Z = new WeakSet(), he = function() {
  if (this.assertOpen(), k(this, H)) throw new p("INVALID_ARGUMENT", "Finish or close the active transcription stream first.");
}, qe), D, ne, me, F, ee, A, te, W, Ke, bt = (Ke = class {
  constructor(s, e) {
    L(this, A);
    M(this, "transport");
    M(this, "maxNewTokens");
    M(this, "ready");
    L(this, D, /* @__PURE__ */ new Map());
    L(this, ne);
    L(this, me, 0);
    L(this, F, !1);
    L(this, ee);
    this.transport = s, this.maxNewTokens = e, this.ready = new Promise((t, i) => {
      C(this, ne, i), s.listen((n) => {
        var o;
        if (!k(this, F)) {
          if (n.type === "ready") t();
          else if (n.type === "error" && n.id === void 0) S(this, A, te).call(this, new p(n.code, n.message));
          else if ("id" in n && n.id !== void 0) {
            const a = k(this, D).get(n.id);
            k(this, D).delete(n.id), n.type === "error" ? a == null || a.reject(new p(n.code, n.message)) : n.type === "result" && (a == null || a.resolve(n.value));
          }
          !k(this, F) && k(this, D).size === 0 && ((o = s.unref) == null || o.call(s));
        }
      }, (n) => {
        k(this, F) || S(this, A, te).call(this, new p("WORKER_ERROR", `Inference worker failed: ${n.message}`, { cause: n }));
      });
    });
  }
  async generate({ prompt: s, tools: e, maxOutputTokens: t, abortSignal: i }) {
    i == null || i.throwIfAborted();
    const n = await this.complete(s, {
      ...e === void 0 ? {} : { tools: e },
      ...t === void 0 ? {} : { maxNewTokens: t },
      ...i === void 0 ? {} : { abortSignal: i }
    });
    if (i == null || i.throwIfAborted(), !n.success) throw new p("ENGINE_ERROR", n.error ?? "Generation failed.");
    const o = (a) => a.map((r) => ({
      toolName: r.name,
      input: r.arguments
    }));
    return {
      toolCalls: o(n.function_calls),
      suppressedToolCalls: o(n.suppressed_calls),
      confidence: n.confidence,
      reasoning: n.reasoning,
      raw: n
    };
  }
  async complete(s = "", e = {}) {
    var i;
    (i = e.abortSignal) == null || i.throwIfAborted(), G(s, "input");
    const t = be(e.maxNewTokens ?? this.maxNewTokens, "maxNewTokens", 1, 65536);
    return await S(this, A, W).call(this, {
      method: "complete",
      input: s,
      maxNewTokens: t,
      ...e.tools === void 0 ? {} : { toolsJson: Xe(e.tools) }
    }, e.abortSignal);
  }
  async embed(s = "", e = {}) {
    var t;
    return (t = e.abortSignal) == null || t.throwIfAborted(), G(s, "input"), await S(this, A, W).call(this, {
      method: "embed",
      input: s
    }, e.abortSignal);
  }
  async transcribe(s, { abortSignal: e, ...t } = {}) {
    e == null || e.throwIfAborted();
    const i = Te(t);
    return await S(this, A, W).call(this, {
      method: "transcribe",
      audio: s,
      settings: i
    }, e);
  }
  async embedAudio(s) {
    return await S(this, A, W).call(this, {
      method: "embedAudio",
      audio: s
    });
  }
  async streamTranscribe(s, e) {
    return await S(this, A, W).call(this, {
      method: "streamTranscribe",
      audio: s,
      settings: e
    });
  }
  async reset() {
    await S(this, A, W).call(this, { method: "reset" });
  }
  close() {
    return k(this, ee) ?? S(this, A, te).call(this, new p("CLOSED", "This Needle instance was closed."));
  }
  [Symbol.asyncDispose]() {
    return this.close();
  }
}, D = new WeakMap(), ne = new WeakMap(), me = new WeakMap(), F = new WeakMap(), ee = new WeakMap(), A = new WeakSet(), te = function(s) {
  var e, t;
  C(this, F, !0), k(this, ne).call(this, s);
  for (const i of k(this, D).values()) i.reject(s);
  return k(this, D).clear(), (t = (e = this.transport).ref) == null || t.call(e), k(this, ee) ?? C(this, ee, this.transport.terminate()), k(this, ee);
}, W = async function(s, e) {
  if (e == null || e.throwIfAborted(), k(this, F)) throw new p("CLOSED", "This model session is closed.");
  const t = () => {
    this.close();
  };
  e == null || e.addEventListener("abort", t, { once: !0 });
  try {
    const i = await new Promise((n, o) => {
      var r, c;
      const a = Ce(this, me)._++;
      k(this, D).set(a, {
        resolve: n,
        reject: o
      }), (c = (r = this.transport).ref) == null || c.call(r);
      try {
        this.transport.send({
          ...s,
          id: a
        });
      } catch (h) {
        S(this, A, te).call(this, new p("WORKER_ERROR", ge(h), { cause: h }));
      }
    });
    return e == null || e.throwIfAborted(), i;
  } catch (i) {
    throw e != null && e.aborted ? e.reason : i;
  } finally {
    e == null || e.removeEventListener("abort", t);
  }
}, Ke);
const wt = async (s, e) => {
  if (e.throwIfAborted(), typeof s == "string" || s instanceof URL) {
    const t = await fetch(s, { signal: e });
    if (!t.ok) throw new p("DOWNLOAD_FAILED", `Audio download failed: HTTP ${t.status}.`);
    return new Uint8Array(await t.arrayBuffer());
  }
  return s instanceof Blob ? new Uint8Array(await s.arrayBuffer()) : s;
};
function ve(s, e) {
  var t;
  try {
    const i = new URL(s, (t = globalThis.location) == null ? void 0 : t.href);
    if (!["http:", "https:", "blob:", "chrome-extension:", "moz-extension:"].includes(i.protocol)) throw new Error("Expected an HTTP(S) URL.");
    return i.href;
  } catch (i) {
    throw new p("INVALID_ARGUMENT", `${e} must be an HTTP(S) URL or page-relative path.`, { cause: i });
  }
}
async function yt(s, e) {
  var f, g, m, v, y, b;
  (f = s.abortSignal) == null || f.throwIfAborted();
  const t = e === "needle3" ? pt : ft, i = Qe(s), n = be(s.maxOutputTokens ?? s.maxNewTokens ?? 512, "maxOutputTokens", 1, 65536);
  for (const u of ["cache", "offline"]) if (s[u] !== void 0 && typeof s[u] != "boolean") throw new p("INVALID_ARGUMENT", `${u} must be a boolean.`);
  if (s.modelSha256 !== void 0 && !/^[a-f0-9]{64}$/i.test(s.modelSha256)) throw new p("INVALID_ARGUMENT", "modelSha256 must be a 64-character hex SHA-256 digest.");
  if (s.onDownloadProgress !== void 0 && typeof s.onDownloadProgress != "function") throw new p("INVALID_ARGUMENT", "onDownloadProgress must be a function.");
  const o = s.model ?? t.url, a = typeof o == "string" || o instanceof URL ? ve(o, "model") : o instanceof ArrayBuffer ? new Uint8Array(o.slice(0)) : o instanceof Uint8Array ? new Uint8Array(o) : void 0;
  if (a === void 0) throw new p("INVALID_ARGUMENT", "model must be a URL, ArrayBuffer, or Uint8Array.");
  const r = a === t.url;
  if (r && s.modelSha256 !== void 0 && s.modelSha256.toLowerCase() !== t.sha256) throw new p("INVALID_ARGUMENT", "The default model checksum cannot be overridden.");
  const c = {
    ...i,
    modelKind: e,
    model: a,
    wasmUrl: s.wasmUrl === void 0 ? new URL("../../vendor/needle.wasm", self.location.href).href : ve(s.wasmUrl, "wasmUrl"),
    cache: s.cache ?? !0,
    offline: s.offline ?? !1,
    ...r ? {
      modelSha256: t.sha256,
      modelSize: t.size
    } : s.modelSha256 ? { modelSha256: s.modelSha256.toLowerCase() } : {}
  };
  if (typeof Worker > "u" || typeof WebAssembly > "u") throw new p("UNSUPPORTED_ENVIRONMENT", "Use the browser entry in a browser with WebAssembly and module workers. For Node.js, import cactus-needle.");
  if (!((g = globalThis.crypto) != null && g.subtle)) throw new p("UNSUPPORTED_ENVIRONMENT", "Browser inference requires HTTPS or localhost for integrity verification.");
  let h;
  try {
    h = s.workerUrl === void 0 ? new Worker(new URL("./worker.js", self.location.href), {
      type: "module",
      name: "cactus-needle"
    }) : new Worker(ve(s.workerUrl, "workerUrl"), {
      type: "module",
      name: "cactus-needle"
    });
  } catch (u) {
    throw new p("WORKER_ERROR", "Cannot start the inference worker. Check workerUrl and your worker-src Content Security Policy.", { cause: u });
  }
  const d = new bt({
    send: (u) => h.postMessage(u),
    terminate: async () => {
      h.terminate();
    },
    listen(u, w) {
      h.onmessage = ({ data: $ }) => {
        var E;
        if ($.type === "progress") try {
          (E = s.onDownloadProgress) == null || E.call(s, $.progress);
        } catch (O) {
          w(O instanceof Error ? O : new Error(String(O)));
        }
        else u($);
      }, h.onerror = ($) => {
        $.preventDefault(), w(new Error($.message || "Could not load worker."));
      }, h.onmessageerror = () => w(/* @__PURE__ */ new Error("Could not decode a worker message."));
    }
  }, n), l = () => {
    d.close();
  };
  (m = s.abortSignal) == null || m.addEventListener("abort", l, { once: !0 });
  try {
    return h.postMessage({
      type: "init",
      config: c
    }, a instanceof Uint8Array ? [a.buffer] : []), await d.ready, (v = s.abortSignal) == null || v.throwIfAborted(), d;
  } catch (u) {
    throw await d.close(), (y = s.abortSignal) != null && y.aborted ? s.abortSignal.reason : u;
  } finally {
    (b = s.abortSignal) == null || b.removeEventListener("abort", l);
  }
}
function Ze(s, e, t) {
  if (s.weights !== void 0 && s.model !== void 0) throw new p("INVALID_ARGUMENT", "Supply weights or model, not both.");
  return yt({
    ...s,
    stateless: !1,
    abortSignal: s.abortSignal ? AbortSignal.any([t, s.abortSignal]) : t,
    ...s.weights === void 0 ? {} : { model: s.weights }
  }, e);
}
const kt = class extends mt {
  constructor(s = {}) {
    super((e) => Ze(s, "needle3", e), s);
  }
}, vt = class extends gt {
  constructor(s = {}) {
    super((e) => Ze(s, "whistle", e), wt);
  }
}, xt = [
  "a[href]",
  "button",
  "input:not([type=hidden])",
  "select",
  "textarea",
  "summary",
  '[contenteditable=""]',
  '[contenteditable="true"]',
  "[role=button]",
  "[role=link]",
  "[role=tab]",
  "[role=menuitem]",
  "[role=checkbox]",
  "[role=switch]",
  "[role=radio]",
  "[role=option]",
  "[data-voice]"
].join(","), T = (s) => (s ?? "").replace(/\s+/g, " ").trim();
function et(s) {
  let e = "";
  return s.childNodes.forEach((t) => {
    t.nodeType === Node.TEXT_NODE ? e += ` ${t.textContent}` : t instanceof HTMLElement && !t.matches("input,select,textarea,button,option,[contenteditable]") && (e += ` ${et(t)}`);
  }), T(e);
}
function pe(s) {
  return s ? T(s.innerText ?? s.textContent) : "";
}
function Ne(s) {
  const e = s.getAttribute("role"), t = s.tagName;
  if (t === "SELECT" || e === "listbox" || e === "combobox") return "select";
  if (t === "INPUT") {
    const i = s.type;
    return i === "checkbox" || i === "radio" ? "check" : ["submit", "button", "reset", "image"].includes(i) ? "button" : i === "password" ? "secret" : "field";
  }
  return t === "TEXTAREA" || s.isContentEditable ? "field" : e === "checkbox" || e === "switch" || e === "radio" ? "check" : e === "tab" ? "tab" : t === "A" || e === "link" ? "link" : "button";
}
function tt(s) {
  const e = s.getAttribute("data-voice");
  if (e) return T(e);
  const t = s.getAttribute("aria-label");
  if (t) return T(t);
  const i = s.getAttribute("aria-labelledby");
  if (i) {
    const c = i.split(/\s+/).map((h) => pe(document.getElementById(h))).join(" ");
    if (T(c)) return T(c);
  }
  const n = s.labels;
  if (n && n.length) {
    const c = Array.from(n).map((h) => et(h)).join(" ");
    if (T(c)) return T(c).replace(/\s*\*$/, "");
  }
  const o = Ne(s);
  if (o === "field" || o === "select") {
    const c = s.getAttribute("placeholder") || s.getAttribute("title") || s.getAttribute("name");
    if (c) return T(c);
  }
  if (s.tagName === "INPUT") {
    const c = s.value;
    if (c) return T(c);
  }
  const a = pe(s);
  if (a) return a.length > 60 ? a.slice(0, 60) : a;
  const r = s.querySelector("img[alt]");
  return T(r ? r.getAttribute("alt") : s.getAttribute("title"));
}
function $t(s) {
  var i;
  if (s.closest('[hidden],[aria-hidden="true"],[inert]') || s.checkVisibility && !s.checkVisibility({ checkVisibilityCSS: !0 }) || s.disabled) return !1;
  const e = s.getBoundingClientRect();
  if ((e.width < 2 || e.height < 2) && !(Ne(s) === "check" && ((i = s.labels) != null && i.length)))
    return !1;
  const t = getComputedStyle(s);
  return t.visibility !== "hidden" && t.display !== "none";
}
function St(s) {
  const e = s.closest("[data-voice-group],article,li,tr,[role=row],.card,section,form");
  if (!e) return "";
  const t = e.getAttribute("data-voice-group");
  if (t) return T(t);
  if (e.tagName === "TR" || e.getAttribute("role") === "row") {
    const i = e.querySelector("td,th,[role=cell],[role=gridcell]");
    return pe(i);
  }
  return pe(e.querySelector("h1,h2,h3,h4,h5,h6,strong,legend"));
}
function U(s) {
  const e = [], t = /* @__PURE__ */ new Set();
  for (const r of Array.from(document.querySelectorAll(xt))) {
    if (t.has(r) || s && s.contains(r) || r.closest("[data-voice]") && r.closest("[data-voice]") !== r || !$t(r)) continue;
    const c = tt(r).replace(/\s*\(\d+\)$/, "");
    if (!c) continue;
    t.add(r);
    const h = Ne(r), d = { num: 0, el: r, kind: h, name: c };
    r.tagName === "SELECT" && (d.options = Array.from(r.options).map((l) => T(l.text)).filter(Boolean)), e.push(d);
  }
  const i = (r) => r.kind === "field" || r.kind === "secret" ? "f" : r.kind === "select" ? "s" : "c", n = (r) => `${i(r)}:${r.name.toLowerCase()}`, o = /* @__PURE__ */ new Map();
  for (const r of e) o.set(n(r), (o.get(n(r)) ?? 0) + 1);
  for (const r of e)
    if ((o.get(n(r)) ?? 0) > 1) {
      const c = St(r.el);
      c && c.toLowerCase() !== r.name.toLowerCase() && (r.item = c, r.action = r.name, r.name = `${r.name} ${c}`);
    }
  const a = /* @__PURE__ */ new Map();
  for (const r of e) {
    const c = r.name.toLowerCase(), h = (a.get(c) ?? 0) + 1;
    a.set(c, h), h > 1 && (r.name = `${r.name} ${h}`);
  }
  return e.forEach((r, c) => r.num = c + 1), e;
}
function Tt(s) {
  const e = s.getBoundingClientRect();
  return e.bottom > 0 && e.right > 0 && e.top < innerHeight && e.left < innerWidth;
}
const Pe = (s) => s.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
function K(s, e) {
  const t = Pe(e);
  if (!t) return;
  let i, n = 0;
  const o = new Set(t.split(" "));
  for (const a of s) {
    const r = Pe(a.name);
    let c = 0;
    if (r === t) c = 1;
    else if (r.startsWith(t) || t.startsWith(r)) c = 0.9;
    else if (r.includes(t) || t.includes(r)) c = 0.8;
    else {
      const h = r.split(" ");
      c = 0.75 * h.filter((l) => o.has(l)).length / Math.max(h.length, o.size);
    }
    c > n && (n = c, i = a);
  }
  return n >= 0.3 ? i : void 0;
}
const At = 80, J = "(?![\\s\\S]*\\b(and|then)\\b)";
function de(s) {
  const e = [];
  for (const t of s) t && !e.includes(t) && e.push(t);
  return e.sort((t, i) => t.localeCompare(i)).slice(0, At);
}
function xe(s, e) {
  return de(s.filter((t) => e.includes(t.kind) && !t.item).map((t) => t.name));
}
function Q(s, e, t = 12) {
  return s;
}
function Et(s, e, t) {
  const i = Q(xe(s, ["link", "button", "tab", "check"])), n = Q(xe(s, ["field"])), o = Q(xe(s, ["select"])), a = s.filter((h) => h.item), r = Q(de(s.flatMap((h) => h.options ?? [])), t, 20), c = {};
  i.length && (c.click = {
    description: "Click, press, tap or open a button, link, tab, menu item or checkbox on the screen.",
    inputSchema: {
      type: "object",
      properties: { target: { type: "string", enum: i, description: "the label of the thing to click" } },
      required: ["target"]
    },
    triggers: [`^${J}\\s*(click|press|tap|open|go to|show me|select|tick|untick|check)\\b`]
  }), a.length && (c.item_action = {
    description: "Do something to one item in a list or table, like add a product to the cart, open, edit or delete a row.",
    inputSchema: {
      type: "object",
      properties: {
        action: { type: "string", enum: Q(de(a.map((h) => h.action))), description: "what to do" },
        item: { type: "string", enum: Q(de(a.map((h) => h.item))), description: "which item" }
      },
      required: ["action", "item"]
    }
  }), n.length && (c.type_text = {
    description: "Type or write text into a box on a form, such as a name, phone, email, search or message.",
    inputSchema: {
      type: "object",
      properties: {
        field: { type: "string", enum: n, description: "the label of the box" },
        text: { type: "string", description: "the exact words to type" }
      },
      required: ["field", "text"]
    },
    triggers: [`^${J}\\s*(type|write|enter|fill|put|search for)\\b`, `^${J}\\s*my \\w+ is\\b`]
  }), o.length && (c.choose_option = {
    description: "Pick an option from a dropdown list, such as a category, status or sort order.",
    inputSchema: {
      type: "object",
      properties: {
        list: { type: "string", enum: o, description: "the label of the dropdown" },
        option: { type: "string", enum: r.length ? r : void 0, description: "the option to pick" }
      },
      required: ["list", "option"]
    },
    triggers: [`^${J}\\s*(choose|pick|sort by|filter by|set .+ to)\\b`]
  }), c.scroll_page = {
    description: "Scroll the page up or down, or jump to the top or bottom.",
    inputSchema: {
      type: "object",
      properties: { direction: { type: "string", enum: ["down", "up", "top", "bottom"] } },
      required: ["direction"]
    },
    triggers: [`^${J}\\s*(scroll|page (up|down)|go to the (top|bottom))\\b`]
  }, c.read_aloud = {
    description: "Read the page, its headings or the form out loud.",
    inputSchema: {
      type: "object",
      properties: { part: { type: "string", enum: ["page", "headings", "form"], default: "page" } }
    },
    triggers: [`^${J}\\s*(read|what does it say|what is on (the|this) (page|screen))\\b`]
  };
  for (const [h, d] of Object.entries(e))
    c[h] = { description: d.description, inputSchema: d.inputSchema, triggers: d.triggers };
  return c;
}
const De = {
  one: 1,
  won: 1,
  two: 2,
  to: 2,
  too: 2,
  three: 3,
  four: 4,
  for: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
  thirteen: 13,
  fourteen: 14,
  fifteen: 15,
  sixteen: 16,
  seventeen: 17,
  eighteen: 18,
  nineteen: 19,
  twenty: 20,
  thirty: 30,
  forty: 40,
  fifty: 50
};
function I(s) {
  return s.toLowerCase().replace(/[.,!?;:"“”]+/g, " ").replace(/\s+/g, " ").replace(/^(please|ok|okay|hey|um|uh|so)\s+/, "").replace(/\s+please$/, "").trim();
}
function it(s) {
  if (/^\d+$/.test(s)) return parseInt(s, 10);
  const e = s.split(/[\s-]+/);
  let t = 0;
  for (const i of e) {
    if (De[i] === void 0) return null;
    t += De[i];
  }
  return t || null;
}
function Nt(s) {
  const e = I(s), t = s.match(/^\s*(?:change|set) (?:the |my )?wake word to\s+["“]?([\p{L}\s'-]{2,30}?)["”]?[.!]?\s*$/iu);
  if (t) return { do: "wake", word: t[1].trim().toLowerCase() };
  if (/^(longer|a longer) pause$|^(wait|give me) (longer|more time)$|^slow listening$/.test(e)) return { do: "pause", dir: 1 };
  if (/^(shorter|a shorter) pause$|^(wait|listen) (less|shorter)$/.test(e)) return { do: "pause", dir: -1 };
  if (/^(open |show )?(voice )?settings$/.test(e)) return { do: "settings" };
  if (/^(check|test|audit) (this|the) (page|site)( for accessibility)?$|^accessibility (check|report)$/.test(e)) return { do: "check" };
  if (/^(yes|yeah|yep|yes please|go ahead|do it|confirm|ok go ahead|sure|ndiyo)$/.test(e)) return { do: "yes" };
  if (/^(no|nope|no thanks|don't|do not|hapana)$/.test(e)) return { do: "no" };
  if (/^(delete that|undo that|undo|scratch that|take that back|remove that)$/.test(e)) return { do: "undo" };
  if (/^(delete|remove|erase) (the )?last word$/.test(e)) return { do: "dropword" };
  if (s.match(/^\s*spell(?:\s+it)?\s*[:,]?\s*(.+)$/i)) return { do: "spell", text: s };
  if (/^(stop|cancel|quiet|shut up|be quiet|stop talking|stop reading|pause|pause reading)$/.test(e)) return { do: "stop" };
  if (/^(narrate|voice|read|talk through)( the| this)? (video|guide|clip)$|^play (the |this )?(video|guide)( with (voice|sound|narration))?$|^read along$|^play with (voice|sound)$/.test(e)) return { do: "narrate", on: !0 };
  if (/^stop (narrating|the video|the narration)$/.test(e)) return { do: "narrate", on: !1 };
  if (/^(continue|resume|keep reading|read on|carry on|go on)( reading)?$/.test(e)) return { do: "resume" };
  if (/^read( this| the)? section$|^read (from )?here$/.test(e)) return { do: "section" };
  let n = e.match(/^(next|previous|last|go to the next|go to the previous)( one)?( (heading|title|paragraph|link|item|line))?$/);
  if (n)
    return { do: "move", what: n[4] === "heading" || n[4] === "title" ? "heading" : n[4] === "link" ? "link" : "paragraph", dir: /next/.test(n[1]) ? 1 : -1 };
  if (/^(where am i|where are we|what page is this|what page am i on)$/.test(e)) return { do: "where" };
  if (/^(read |speak |talk )?(faster|quicker|speed up)$/.test(e)) return { do: "rate", dir: 1 };
  if (/^(read |speak |talk )?(slower|slow down|more slowly)$/.test(e)) return { do: "rate", dir: -1 };
  if (/^(list|read|what are)( the| all)? headings$/.test(e)) return { do: "read", part: "headings" };
  if (/^(go to sleep|sleep|that's all|that is all|thank you|thanks|never mind|nevermind)$/.test(e)) return { do: "sleep" };
  if (/^(stop listening|turn off voice( control)?|mic off|turn off the mic)$/.test(e)) return { do: "off" };
  if (/^(menu|show (the |me the )?menu|options|show (me )?(the )?options|what can i do( here| on this page)?|help me|list (the )?actions)$/.test(e)) return { do: "menu", act: "open" };
  if (e.split(" ").length <= 5 && /\b(menu|options)\b/.test(e) && !/\b(close|hide|exit|cancel|dismiss)\b/.test(e)) return { do: "menu", act: "open" };
  if (/^(more|show more|next page|more options)$/.test(e)) return { do: "menu", act: "more" };
  if (/^(previous page|back a page|fewer)$/.test(e)) return { do: "menu", act: "back" };
  if (/^(close|close it|close (the )?(menu|list|dialog|options)|hide (the )?(menu|list|options)|exit( menu)?|cancel|dismiss|go away|never mind the menu)$/.test(e)) return { do: "menu", act: "close" };
  if (e.split(" ").length <= 6) {
    if (/\b(minimi[sz]e\w*|minimum|shrink|smaller|collapse)\b/.test(e)) return { do: "panel", open: !1 };
    if (/\b(expand|maximi[sz]e\w*|bigger|restore|unminimi[sz]e)\b|^open (the |voice )?(panel|control)/.test(e)) return { do: "panel", open: !0 };
  }
  const o = "(?:the )?(?:microphone|mic|panel|voice(?: control)?|it|button)";
  let a = e.match(new RegExp(`^(?:drag|move|push|slide) ${o} (up|down|left|right)(?: (a bit|a little|a lot|more|much more|slightly))?$`));
  if (a) {
    const d = /a lot|much/.test(a[2] ?? "") ? 320 : /bit|little|slightly/.test(a[2] ?? "") ? 60 : 140, l = { up: [0, -d], down: [0, d], left: [-d, 0], right: [d, 0] }, [f, g] = l[a[1]];
    return { do: "drag", dx: f, dy: g };
  }
  if (a = e.match(new RegExp(`^(?:drag|move|put|place) ${o} (?:to )?(?:the )?(top|bottom|middle|centre|center)(?: (left|right|middle|centre|center))?(?: corner| side)?$`)), a) {
    const d = a[1] === "top" ? "top" : a[1] === "bottom" ? "bottom" : "middle", l = a[2] === "left" ? "left" : a[2] === "right" || a[1] === "top" || a[1] === "bottom" ? "right" : "center";
    return { do: "place", v: d, h: l };
  }
  if (/^(minimi[sz]e|hide|collapse|shrink|close)( the| this)?( voice| voice control| panel| voice panel| box| window| it)?$|^make (it|the panel) (smaller|small)$|^(get|move) out of the way$/.test(e)) return { do: "panel", open: !1 };
  if (/^(show|open|expand|maximi[sz]e|restore|unminimi[sz]e)( the)?( voice| voice control| panel| voice panel| box| window| it)?$|^make (it|the panel) (bigger|big|larger)$/.test(e)) return { do: "panel", open: !0 };
  if (/^(help|what can i say|what can i do( here)?|commands)$/.test(e)) return { do: "help" };
  if (/^(show|give me)( the)? numbers$|^numbers$/.test(e)) return { do: "numbers", on: !0 };
  if (/^(hide|remove|clear)( the)? numbers$/.test(e)) return { do: "numbers", on: !1 };
  if (/^(go )?back$|^previous page$/.test(e)) return { do: "back" };
  if (/^(go )?forward$|^next page$/.test(e)) return { do: "forward" };
  if (/^(reload|refresh)( the)?( page)?$/.test(e)) return { do: "reload" };
  if (/^(submit|send)( it| this| the form)?$/.test(e)) return { do: "submit" };
  if (/^(clear|delete|erase) (it|this|that|the box|the field)$/.test(e)) return { do: "clear" };
  if (/^(new line|next line)$/.test(e)) return { do: "newline" };
  let r = e.match(/^(?:scroll|go|page|move)(?: the page)? (up|down)$|^(?:scroll |go )?(?:to )?(?:the )?(top|bottom)(?: of the page)?$/);
  if (r) return { do: "scroll", direction: r[1] ?? r[2] };
  if (/^(scroll|page down)$/.test(e)) return { do: "scroll", direction: "down" };
  if (r = e.match(/^read( out| aloud)?( the| this)? ?(page|headings|form|screen|it)?( out| aloud)?$/), r) return { do: "read", part: r[3] === "headings" ? "headings" : r[3] === "form" ? "form" : "page" };
  if (/^what('s| is) on (the|this) (page|screen)$/.test(e)) return { do: "read", part: "page" };
  const c = s.trim().replace(/[.!?]+$/, "");
  if (r = c.match(/^(?:please\s+)?(?:type|write|enter|put|fill in)\s+(.+)\s+(?:in|into)\s+(?:the\s+|my\s+)?(.+?)(?:\s+(?:box|field))?$/i), r) return { do: "type", text: r[1], field: r[2] };
  if (r = c.match(/^(?:my|the|our)\s+(.+?)\s+is\s+(.+)$/i), r) return { do: "type", field: r[1], text: r[2] };
  const h = e.match(/^(?:(?:click|press|tap|choose|pick|select|open)\s+)?(?:number\s+)?([a-z0-9 -]+)$/);
  if (h && (/^number /.test(e) || /^(click|press|tap|choose|pick|select|open) /.test(e) || /^\d+$/.test(e))) {
    const d = it(h[1].trim());
    if (d) return { do: "number", n: d };
  }
  return null;
}
function je(s) {
  return I(s).replace(/^(click|press|tap|open|go to|take me to|show me|show|select|choose|i want|go)\s+(on\s+)?/, "").replace(/^(the|my|a)\s+/, "").replace(/\s+(button|link|tab|page|menu)$/, "").trim();
}
const ae = {
  zero: "0",
  oh: "0",
  o: "0",
  nil: "0",
  one: "1",
  two: "2",
  three: "3",
  four: "4",
  for: "4",
  five: "5",
  six: "6",
  seven: "7",
  eight: "8",
  nine: "9",
  to: "2",
  too: "2",
  ate: "8"
};
function Lt(s) {
  const e = s.toLowerCase().replace(/[,.-]/g, " ").split(/\s+/).filter(Boolean);
  let t = "";
  for (let i = 0; i < e.length; i++) {
    const n = e[i], o = e[i + 1];
    if ((n === "double" || n === "triple") && o && (ae[o] || /^\d$/.test(o))) {
      const a = ae[o] ?? o;
      t += a.repeat(n === "double" ? 2 : 3), i++;
    } else if (/^\+?\d+$/.test(n)) t += n;
    else if (ae[n] !== void 0) t += ae[n];
    else if (n === "plus" && !t) t += "+";
    else return s;
  }
  return t;
}
function It(s) {
  let e = ` ${s.toLowerCase().trim()} `;
  return e = e.replace(/\s+at\s+/g, "@").replace(/\s+dot\s+/g, ".").replace(/\s+(underscore)\s+/g, "_").replace(/\s+(dash|hyphen)\s+/g, "-"), e.trim().replace(/\s+/g, "");
}
function Ct(s) {
  const e = s.match(/^\s*spell(?:\s+it)?\s*[:,]?\s*(.+)$/i);
  if (!e) return null;
  const t = e[1].split(/[\s,.-]+/).filter(Boolean);
  return t.every((i) => i.length === 1 || /^\d+$/.test(i)) ? t.join("") : null;
}
function Mt(s, e) {
  const t = e, i = (t.type || "").toLowerCase(), n = `${t.name ?? ""} ${t.autocomplete ?? ""} ${t.getAttribute("inputmode") ?? ""}`.toLowerCase();
  return i === "email" || /email/.test(n) || /\s+at\s+.+\s+dot\s+/i.test(s) ? It(s) : i === "tel" || /tel|phone|mobile/.test(n) || i === "number" || /numeric|decimal/.test(n) ? Lt(s) : s;
}
const Ae = /* @__PURE__ */ new WeakMap();
function Rt(s, e) {
  Ae.set(s, e);
}
function Ot(s) {
  const e = Ae.get(s);
  return !e || !s.value.endsWith(e) ? null : (Ae.delete(s), s.value.slice(0, s.value.length - e.length).replace(/\s+$/, ""));
}
function Ut(s) {
  return s.replace(/\s*\S+\s*$/, "");
}
function X(s, e) {
  const t = s.getBoundingClientRect(), i = document.createElement("div");
  i.className = "flash", Object.assign(i.style, {
    left: `${t.left - 4}px`,
    top: `${t.top - 4}px`,
    width: `${t.width + 8}px`,
    height: `${t.height + 8}px`
  }), e.appendChild(i), setTimeout(() => i.remove(), 900);
}
function Le(s) {
  const e = s.getBoundingClientRect();
  (e.top < 0 || e.bottom > innerHeight) && s.scrollIntoView({ block: "center", behavior: "instant" });
}
function Pt(s) {
  Le(s.el), s.el.focus({ preventScroll: !0 }), s.el.click();
}
function B(s, e, t = !1) {
  var a;
  const i = s.el;
  if (s.kind === "secret" || i.type === "password") throw new Error("password boxes are never typed into by voice");
  Le(s.el), i.focus({ preventScroll: !0 }), e = e && Mt(e, s.el);
  const n = s.el.isContentEditable ? s.el.textContent ?? "" : i.value;
  if (s.el.isContentEditable)
    s.el.textContent = t ? `${s.el.textContent ?? ""} ${e}` : e;
  else {
    const r = i instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype, c = (a = Object.getOwnPropertyDescriptor(r, "value")) == null ? void 0 : a.set, h = t && i.value ? `${i.value} ${e}` : e;
    c ? c.call(i, h) : i.value = h;
  }
  s.el.dispatchEvent(new Event("input", { bubbles: !0 })), s.el.dispatchEvent(new Event("change", { bubbles: !0 }));
  const o = s.el.isContentEditable ? s.el.textContent ?? "" : i.value;
  return o.startsWith(n) && Rt(s.el, o.slice(n.length)), e;
}
function Dt(s, e) {
  var n, o;
  const t = s.el, i = t instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  (o = (n = Object.getOwnPropertyDescriptor(i, "value")) == null ? void 0 : n.set) == null || o.call(t, e), t.dispatchEvent(new Event("input", { bubbles: !0 })), t.dispatchEvent(new Event("change", { bubbles: !0 }));
}
function _e(s, e, t) {
  var r;
  const i = s.el, n = Array.from(i.options).map((c, h) => ({ name: c.text, i: h })), o = t(n, e);
  if (!o) return !1;
  Le(s.el);
  const a = (r = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value")) == null ? void 0 : r.set;
  return a ? a.call(i, i.options[o.i].value) : i.selectedIndex = o.i, i.dispatchEvent(new Event("input", { bubbles: !0 })), i.dispatchEvent(new Event("change", { bubbles: !0 })), o.name;
}
function ze(s) {
  const e = innerHeight * 0.8, t = { behavior: "smooth" };
  s === "top" ? scrollTo({ top: 0, ...t }) : s === "bottom" ? scrollTo({ top: document.documentElement.scrollHeight, ...t }) : scrollBy({ top: s === "up" ? -e : e, ...t });
}
function jt(s) {
  const e = document.activeElement, t = (e == null ? void 0 : e.closest("form")) ?? document.querySelector("form");
  if (t)
    return s.find(
      (i) => t.contains(i.el) && (i.el.matches("[type=submit]") || i.el.tagName === "BUTTON" && !i.el.getAttribute("type"))
    );
}
function Ve(s, e) {
  var n;
  if (s === "headings")
    return Array.from(document.querySelectorAll("h1,h2,h3")).filter((a) => !e.contains(a)).map((a) => a.innerText.trim()).filter(Boolean).join(". ");
  if (s === "form") {
    const o = ((n = document.activeElement) == null ? void 0 : n.closest("form")) ?? document.querySelector("form");
    return o ? Array.from(o.querySelectorAll("input,select,textarea")).filter((r) => r.type !== "hidden").map((r) => {
      var d, l;
      const c = ((l = (d = r.labels) == null ? void 0 : d[0]) == null ? void 0 : l.innerText.trim()) || r.placeholder || r.name, h = r.type === "checkbox" || r.type === "radio" ? r.checked ? "ticked" : "not ticked" : r.value || "empty";
      return `${c}: ${h}`;
    }).join(". ") : "There is no form on this page.";
  }
  const i = (document.querySelector("main") ?? document.body).innerText.replace(/\s+/g, " ").trim();
  return `${document.title}. ${i}`.slice(0, 1200);
}
const _t = `
class Tap extends AudioWorkletProcessor {
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (ch) this.port.postMessage(ch.slice(0));
    return true;
  }
}
registerProcessor('voicenav-tap', Tap);
`;
class zt {
  // longest piece sent for transcription (750 = 15 s)
  constructor(e, t) {
    this.onUtterance = e, this.onLevel = t, this.chunks = [], this.pre = [], this.speaking = !1, this.loud = 0, this.quiet = 0, this.floor = 4e-3, this.paused = !1, this.startedAt = 0, this.quietBlocks = 40, this.maxBlocks = 750;
  }
  get running() {
    return !!this.ctx;
  }
  async start() {
    if (this.ctx) return;
    if (this.stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: !0, noiseSuppression: !0, autoGainControl: !0, channelCount: 1 }
    }), this.ctx = new AudioContext(), this.ctx.state === "suspended") {
      const o = this.ctx, a = () => o.resume().catch(() => {
      });
      a();
      for (const r of ["pointerdown", "keydown", "touchstart"]) addEventListener(r, a, { once: !0, capture: !0 });
    }
    const e = this.ctx.createMediaStreamSource(this.stream);
    let t = [];
    const i = Math.round(this.ctx.sampleRate / 50), n = (o) => {
      for (let a = 0; a < o.length; a++) t.push(o[a]);
      t.length >= i && (this.feed(Float32Array.from(t)), t = []);
    };
    try {
      const o = URL.createObjectURL(new Blob([_t], { type: "text/javascript" }));
      await Promise.race([
        this.ctx.audioWorklet.addModule(o),
        new Promise((r, c) => setTimeout(() => c(new Error("worklet timeout")), 3e3))
      ]), URL.revokeObjectURL(o);
      const a = new AudioWorkletNode(this.ctx, "voicenav-tap");
      a.port.onmessage = ({ data: r }) => n(r), e.connect(a), this.node = a;
    } catch {
      const o = this.ctx.createScriptProcessor(2048, 1, 1);
      o.onaudioprocess = (a) => n(a.inputBuffer.getChannelData(0)), e.connect(o), o.connect(this.ctx.destination), this.node = o;
    }
  }
  stop() {
    var e, t, i;
    (e = this.node) == null || e.disconnect(), (t = this.stream) == null || t.getTracks().forEach((n) => n.stop()), (i = this.ctx) == null || i.close(), this.ctx = void 0, this.reset();
  }
  reset() {
    this.chunks = [], this.speaking = !1, this.loud = 0, this.quiet = 0;
  }
  feed(e) {
    let t = 0;
    for (let a = 0; a < e.length; a++) t += e[a] * e[a];
    const i = Math.sqrt(t / e.length);
    if (this.onLevel(i, this.speaking), this.paused) {
      this.reset();
      return;
    }
    const n = Math.max(0.012, this.floor * 3);
    if (!this.speaking) {
      this.floor = this.floor * 0.98 + i * 0.02, this.pre.push(e), this.pre.length > 15 && this.pre.shift(), this.loud = i > n ? this.loud + 1 : 0, this.loud >= 3 && (this.speaking = !0, this.startedAt = Date.now() - this.pre.length * 20, this.chunks = [...this.pre], this.pre = []);
      return;
    }
    this.chunks.push(e), this.quiet = i < n * 0.7 ? this.quiet + 1 : 0;
    const o = this.chunks.length;
    if (this.quiet >= this.quietBlocks || o >= this.maxBlocks) {
      const a = this.chunks.reduce((d, l) => d + l.length, 0), r = new Float32Array(a);
      let c = 0;
      for (const d of this.chunks)
        r.set(d, c), c += d.length;
      const h = this.ctx.sampleRate;
      this.reset(), o - this.quietBlocks >= 12 && this.onUtterance({ samples: r, sampleRate: h, startedAt: this.startedAt });
    }
  }
}
const Vt = `
:host { all: initial; }
* { box-sizing: border-box; font-family: "Atkinson Hyperlegible Next", "Atkinson Hyperlegible", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
.panel {
  position: fixed; right: 16px; bottom: 16px; z-index: 2147483646;
  width: 320px; max-width: calc(100vw - 32px);
  background: #2a1b5c; color: #ece6ff; border-radius: 20px;
  box-shadow: 0 18px 48px rgba(29, 19, 66, .45), inset 0 0 0 1px rgba(143, 114, 232, .45);
  padding: 12px; font-size: 15px; line-height: 1.45;
}
.panel.min { width: auto; max-width: min(360px, calc(100vw - 32px)); padding: 6px 8px 6px 6px; border-radius: 999px; }
.panel.min .body, .panel.min .head, .panel.min .min-btn { display: none; }
.panel.min .mic { width: 52px; height: 52px; }
/* Minimized: what the mic heard shows in a caption under (or above) the pill. */
.mini, .max-btn { display: none; }
.panel.min .mini {
  display: block; position: absolute; left: 0; top: calc(100% + 8px); width: max-content; max-width: min(320px, calc(100vw - 32px));
  background: #1d1342; color: #fff; border-radius: 12px; padding: 7px 12px; font-size: 14px; line-height: 1.35;
  box-shadow: 0 8px 24px rgba(29, 19, 66, .4), inset 0 0 0 1px rgba(143, 114, 232, .45);
}
.panel.min.cap-up .mini { top: auto; bottom: calc(100% + 8px); }
.panel.min .mini:empty { display: none; }
.panel.min .mini b { display: block; font-weight: 600; }
.panel.min .max-btn { display: grid; place-items: center; flex: none; width: 24px; height: 24px; padding: 0; border-radius: 6px; color: #b9acec; align-self: center; }
.panel.min .max-btn:hover { color: #fff; background: rgba(236, 230, 255, .12); }
.max-btn svg { width: 14px; height: 14px; }
.panel { touch-action: none; }
.panel.dragging { cursor: grabbing; transition: none; }
.panel.placed { right: auto; bottom: auto; }
.top { display: flex; align-items: center; gap: 12px; }
.head { flex: 1; min-width: 0; }
.title { display: flex; align-items: center; gap: 7px; font-weight: 700; font-size: 13px; color: #b9acec; }
.title svg { width: 16px; height: 16px; }
.status { color: #fff; font-weight: 700; font-size: 15px; margin-top: 1px; min-height: 21px; }
.mic {
  width: 56px; height: 56px; border-radius: 50%; border: 0; cursor: pointer; flex: none;
  background: #3d2b7a; color: #ece6ff; display: grid; place-items: center;
  box-shadow: 0 0 0 calc(var(--lvl, 0) * 12px) rgba(255, 212, 92, .28);
  transition: background .15s;
}
.mic svg { width: 26px; height: 26px; }
/* Each state has its own colour AND words (the .state label), never colour alone. */
.mic.off { background: #3a3550; color: #b8b2cc; }
.mic.on { background: #1f6f43; color: #fff; box-shadow: 0 0 0 3px #4ade80, 0 0 0 calc(3px + var(--lvl, 0) * 12px) rgba(74, 222, 128, .25); }
.mic.sleep { background: #2563eb; color: #fff; }
.mic.awake { background: #ffd45c; color: #1d1440; box-shadow: 0 0 0 4px rgba(255, 212, 92, .4), 0 0 0 calc(4px + var(--lvl, 0) * 12px) rgba(255, 212, 92, .22); }
.mic.hearing { background: #22c55e; color: #052e16; box-shadow: 0 0 0 calc(4px + var(--lvl, 0) * 14px) rgba(34, 197, 94, .3); }
.mic.busy { background: #8f72e8; color: #fff; }
.mic.talking { background: #f472b6; color: #3b0a24; }
.state { display: inline-flex; align-items: center; gap: 6px; margin-top: 4px; padding: 2px 9px; border-radius: 999px; font-size: 12.5px; font-weight: 700; background: rgba(236, 230, 255, .12); color: #fff; white-space: nowrap; }
.state::before { content: ""; width: 8px; height: 8px; border-radius: 50%; background: currentColor; }
.state.off { color: #b8b2cc; }
.state.on, .state.hearing { color: #4ade80; }
.state.sleep { color: #93c5fd; }
.state.awake { color: #ffd45c; }
.state.busy { color: #c4b5fd; }
.state.talking { color: #f9a8d4; }
.mstate { display: none; }
.panel.min .mstate { display: inline-flex; margin: 0; }
button:focus-visible, input:focus-visible, select:focus-visible, summary:focus-visible { outline: 3px solid #ffd45c; outline-offset: 2px; }
.icon { background: none; border: 0; color: #b9acec; cursor: pointer; font-size: 20px; line-height: 1; padding: 6px 8px; border-radius: 8px; align-self: flex-start; }
.icon:hover { background: rgba(236, 230, 255, .1); color: #fff; }
.body { margin-top: 10px; }
.said { color: #fff; font-weight: 700; min-height: 0; }
.said:empty, .did:empty { display: none; }
.did { color: #c8f0d8; margin-top: 2px; }
.did.err { color: #ffc2c2; }
.row { display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap; }
.toggle { display: inline-flex; align-items: center; gap: 8px; padding: 7px 12px; border-radius: 999px; background: rgba(236, 230, 255, .08); cursor: pointer; font-size: 13.5px; color: #ece6ff; }
.toggle input { accent-color: #ffd45c; width: 16px; height: 16px; margin: 0; }
details.more { margin-top: 10px; border-top: 1px solid rgba(143, 114, 232, .35); padding-top: 8px; }
details.more summary { cursor: pointer; color: #b9acec; font-size: 13.5px; padding: 4px 2px; border-radius: 6px; }
details.settings { margin-top: 4px; }
.set { display: grid; gap: 10px; margin-top: 8px; font-size: 13.5px; }
.set label { display: grid; gap: 4px; color: #d9d1fb; }
.set label.toggle { display: inline-flex; }
.set select { background: #1d1342; color: #fff; border: 1px solid rgba(143, 114, 232, .5); border-radius: 10px; padding: 8px; font-size: 14px; }
.sw { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; color: #d9d1fb; }
.chip { background: rgba(236, 230, 255, .1); color: #ece6ff; border: 0; border-radius: 999px; padding: 6px 12px; cursor: pointer; font-size: 13px; }
.chip:hover { background: rgba(236, 230, 255, .2); }
form { display: flex; gap: 6px; margin-top: 8px; }
input[type=text] {
  flex: 1; min-width: 0; background: #1d1342; color: #fff; border: 1px solid rgba(143, 114, 232, .5);
  border-radius: 10px; padding: 9px 11px; font-size: 14px;
}
input[type=text]::placeholder { color: #9d90cf; }
.help { margin: 8px 0 0; padding-left: 18px; max-height: 170px; overflow: auto; font-size: 13.5px; color: #d9d1fb; }
.help li { margin: 3px 0; }
.log { margin-top: 8px; font-size: 12.5px; color: #a99ddb; max-height: 96px; overflow: auto; }
.log div { padding: 3px 0; border-top: 1px solid rgba(143, 114, 232, .2); }
.badges { position: fixed; inset: 0; pointer-events: none; z-index: 2147483645; }
.badge {
  position: fixed; background: #ffd45c; color: #1d1440; font: 700 12px/1 system-ui, sans-serif;
  padding: 4px 6px; border-radius: 7px; box-shadow: 0 1px 4px rgba(0,0,0,.4); transform: translate(-30%, -40%);
}
.reading {
  position: fixed; border: 3px solid #ffd45c; border-radius: 8px; pointer-events: none; z-index: 2147483645;
  background: rgba(255, 212, 92, .12); box-shadow: 0 0 0 4px rgba(42, 27, 92, .35);
}
.menu {
  position: fixed; left: 50%; top: 50%; transform: translate(-50%, -50%); z-index: 2147483647;
  width: min(520px, calc(100vw - 32px)); max-height: calc(100vh - 48px); overflow: auto;
  background: #2a1b5c; color: #ece6ff; border-radius: 20px; padding: 18px 20px;
  box-shadow: 0 24px 64px rgba(29, 19, 66, .55), inset 0 0 0 1px rgba(143, 114, 232, .5);
}
.menu[hidden] { display: none; }
.menu h2 { margin: 0 0 4px; font-size: 18px; color: #fff; }
.menu p { margin: 0 0 12px; font-size: 14px; color: #b9acec; }
.menu ol { list-style: none; margin: 0; padding: 0; display: grid; gap: 6px; }
.menu li button {
  display: flex; align-items: center; gap: 12px; width: 100%; text-align: left; cursor: pointer;
  background: rgba(236, 230, 255, .07); color: #fff; border: 0; border-radius: 12px; padding: 10px 12px; font-size: 16px;
}
.menu li button:hover { background: rgba(236, 230, 255, .14); }
.menu li b { flex: none; width: 32px; height: 32px; border-radius: 50%; display: grid; place-items: center; background: #ffd45c; color: #1d1440; font-size: 16px; }
.menu .foot { display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap; }
.flash {
  position: fixed; border: 3px solid #ffd45c; border-radius: 8px; pointer-events: none;
  z-index: 2147483645; animation: fl .9s ease-out forwards;
}
@keyframes fl { from { opacity: 1; } to { opacity: 0; } }
@media (prefers-reduced-motion: reduce) { .flash { animation-duration: 1.6s; } .mic { transition: none; } }
`, Ft = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v5M8 22h8"/></svg>';
class Bt {
  constructor(e, t) {
    this.$ = (a) => this.root.querySelector(a), this.badgesOn = null, this.raf = 0, this.host = document.createElement("voice-nav"), this.root = this.host.attachShadow({ mode: "open" }), this.root.innerHTML = `
      <style>${Vt}</style>
      <div class="badges" aria-hidden="true"></div>
      <section class="menu" role="dialog" aria-modal="false" aria-labelledby="vn-menu-title" hidden>
        <h2 id="vn-menu-title">What you can do here</h2>
        <p class="menu-hint">Say a number.</p>
        <ol></ol>
        <div class="foot">
          <button type="button" class="chip menu-more">More</button>
          <button type="button" class="chip menu-close">Close</button>
        </div>
      </section>
      <section class="panel${t.minimized ? " min" : ""}" role="region" aria-label="Voice control">
        <div class="top">
          <button class="mic" type="button" aria-label="Start listening" title="Start or stop listening (Alt+V)">${Ft}</button>
          <div class="head">
            <div class="title"><svg viewBox="0 0 40 40" aria-hidden="true"><rect x="3" y="15" width="6" height="10" rx="3" fill="#b9acec"/><rect x="12" y="9" width="6" height="22" rx="3" fill="#ece6ff"/><rect x="21" y="4" width="6" height="32" rx="3" fill="#ffd45c"/><rect x="30" y="12" width="6" height="16" rx="3" fill="#8f72e8"/></svg>Voice control</div>
            <div class="status" aria-live="polite">Starting…</div>
            <div class="state off">Mic off</div>
          </div>
          <div class="state mstate off">Mic off</div>
          <div class="mini" aria-live="polite"><b>Say “expand” to open</b></div>
          <button class="icon max-btn" type="button" aria-label="Open voice control" title="Open voice control (say “expand”)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 15l6-6 6 6"/></svg></button>
          <button class="icon min-btn" type="button" aria-label="Make smaller" title="Make smaller (say “minimize”)">–</button>
        </div>
        <div class="body">
          <div class="said"></div>
          <div class="did" aria-live="polite"></div>
          <div class="row">
            <label class="toggle" title="Listens all the time and acts when you start with “${t.wake}”"><input type="checkbox" class="hf" ${t.handsFree ? "checked" : ""}/> Keep listening</label>
            <label class="toggle"><input type="checkbox" class="sp" ${t.speak ? "checked" : ""}/> Talk back</label>
          </div>
          <details class="more">
            <summary>More: type a command, what to say, history</summary>
            <form>
              <input type="text" placeholder="Type what to do" aria-label="Type a command" />
              <button class="icon" type="submit" aria-label="Do it">↵</button>
            </form>
            <ul class="help"></ul>
            <div class="log"></div>
          </details>
          <details class="more settings">
            <summary>Settings</summary>
            <div class="set">
              <label>Wake word <input type="text" class="wake" value="${t.wake}" aria-label="Wake word" /></label>
              <label>Wait before acting
                <select class="pause" aria-label="Wait before acting">
                  <option value="short">Short pause (0.8 s)</option>
                  <option value="medium">Medium pause (1.4 s)</option>
                  <option value="long">Long pause (2.2 s)</option>
                </select>
              </label>
              <div class="sw">
                <span>Switch key: <b class="swname">${t.switchKey || "none"}</b></span>
                <button type="button" class="chip setkey">Set key</button>
                <button type="button" class="chip clearkey">Clear</button>
              </div>
              <label class="toggle"><input type="checkbox" class="scan" ${t.scan ? "checked" : ""}/> Switch scanning (press to move, twice to choose)</label>
              <button type="button" class="chip check">Check this page for accessibility problems</button>
            </div>
          </details>
        </div>
      </section>`, this.$(".mic").onclick = e.onMic, this.$(".min-btn").onclick = () => e.onMinimize(!0), this.$(".max-btn").onclick = () => e.onMinimize(!1), this.$("form").onsubmit = (a) => {
      a.preventDefault();
      const r = this.$("input[type=text]");
      r.value.trim() && e.onTyped(r.value.trim()), r.value = "";
    };
    const i = this.$("input.wake");
    i.onchange = () => e.onWake(i.value);
    const n = this.$("select.pause");
    n.value = t.pause, n.onchange = () => e.onPause(n.value), this.$("input.scan").onchange = (a) => e.onScan(a.target.checked), this.$(".menu-more").onclick = () => {
      var a;
      return (a = this.menuNav) == null ? void 0 : a.call(this, "more");
    }, this.$(".menu-close").onclick = () => {
      var a;
      return (a = this.menuNav) == null ? void 0 : a.call(this, "close");
    }, this.$(".check").onclick = () => e.onTyped("check this page"), this.$(".clearkey").onclick = () => {
      this.$(".swname").textContent = "none", e.onSwitchKey("");
    }, this.$(".setkey").onclick = () => {
      this.$(".swname").textContent = "press a key…";
      const a = (r) => {
        r.code === "Tab" || r.code === "Escape" || (r.preventDefault(), r.stopPropagation(), removeEventListener("keydown", a, !0), this.$(".swname").textContent = r.code, e.onSwitchKey(r.code));
      };
      addEventListener("keydown", a, !0);
    }, this.$(".hf").onchange = (a) => e.onHandsFree(a.target.checked), this.$(".sp").onchange = (a) => e.onSpeak(a.target.checked), document.documentElement.appendChild(this.host), this.enableDrag();
    try {
      const a = JSON.parse(localStorage.getItem("voicenav:pos") ?? "null");
      a && requestAnimationFrame(() => this.moveTo(a.x, a.y, !1));
    } catch {
    }
    addEventListener("resize", () => {
      const a = this.$(".panel");
      a.classList.contains("placed") && this.moveTo(parseFloat(a.style.left), parseFloat(a.style.top), !1);
    });
    const o = () => {
      cancelAnimationFrame(this.raf), this.raf = requestAnimationFrame(() => this.badgesOn && this.drawBadges(this.badgesOn));
    };
    addEventListener("scroll", o, { passive: !0, capture: !0 }), addEventListener("resize", o);
  }
  // Show what the mic heard in the small panel's caption, above the pill when
  // the pill sits in the lower half of the screen.
  heard(e) {
    this.$(".mini b").textContent = `“${e}”`;
    const t = this.$(".panel");
    t.classList.toggle("cap-up", t.getBoundingClientRect().top > innerHeight / 2);
  }
  showMenu(e, t, i, n, o) {
    const a = this.$(".menu");
    this.$("#vn-menu-title").textContent = e, this.$(".menu-hint").textContent = n;
    const r = this.$(".menu ol");
    r.innerHTML = "", t.forEach((c, h) => {
      const d = document.createElement("li"), l = document.createElement("button");
      l.type = "button", l.innerHTML = `<b>${i + h}</b><span></span>`, l.querySelector("span").textContent = c, l.onclick = () => {
        var f;
        return (f = this.menuPick) == null ? void 0 : f.call(this, i + h);
      }, d.appendChild(l), r.appendChild(d);
    }), this.$(".menu-more").hidden = !o, a.hidden = !1;
  }
  hideMenu() {
    this.$(".menu").hidden = !0;
  }
  get menuOpen() {
    return !this.$(".menu").hidden;
  }
  // Moving the panel: by mouse or finger from any part that isn't a control,
  // or by voice. Kept inside the window and remembered on this device.
  moveTo(e, t, i = !0) {
    const n = this.$(".panel"), o = n.getBoundingClientRect();
    if (e = Math.max(8, Math.min(innerWidth - o.width - 8, e)), t = Math.max(8, Math.min(innerHeight - o.height - 8, t)), n.classList.add("placed"), n.style.left = `${e}px`, n.style.top = `${t}px`, i)
      try {
        localStorage.setItem("voicenav:pos", JSON.stringify({ x: e, y: t }));
      } catch {
      }
  }
  moveBy(e, t) {
    const i = this.$(".panel").getBoundingClientRect();
    this.moveTo(i.left + e, i.top + t);
  }
  place(e, t) {
    const i = this.$(".panel").getBoundingClientRect(), n = t === "left" ? 16 : t === "right" ? innerWidth - i.width - 16 : (innerWidth - i.width) / 2, o = e === "top" ? 16 : e === "bottom" ? innerHeight - i.height - 16 : (innerHeight - i.height) / 2;
    this.moveTo(n, o);
  }
  enableDrag() {
    const e = this.$(".panel");
    let t = null, i = !1;
    e.addEventListener("pointerdown", (o) => {
      if (o.target.closest("button,input,select,summary,a,label,.menu")) return;
      const a = e.getBoundingClientRect();
      t = { x: o.clientX, y: o.clientY, left: a.left, top: a.top, id: o.pointerId }, i = !1;
    }), e.addEventListener("pointermove", (o) => {
      if (!t || o.pointerId !== t.id) return;
      const a = o.clientX - t.x, r = o.clientY - t.y;
      !i && Math.hypot(a, r) < 5 || (i || (i = !0, e.setPointerCapture(o.pointerId), e.classList.add("dragging")), this.moveTo(t.left + a, t.top + r, !1));
    });
    const n = (o) => {
      !t || o.pointerId !== t.id || (i && (e.classList.remove("dragging"), this.moveTo(parseFloat(e.style.left), parseFloat(e.style.top))), t = null);
    };
    e.addEventListener("pointerup", n), e.addEventListener("pointercancel", n);
  }
  get minimized() {
    return this.$(".panel").classList.contains("min");
  }
  minimize(e) {
    const t = this.$(".panel");
    t.classList.toggle("min", e), t.classList.toggle("cap-up", t.getBoundingClientRect().top > innerHeight / 2), this.$(".mic").title = e ? "Voice control. Say “show voice control” to open it." : "Start or stop listening (Alt+V)";
  }
  status(e) {
    this.$(".status").textContent = e;
  }
  said(e) {
    this.$(".said").textContent = e ? `“${e}”` : "", e && this.heard(e);
  }
  did(e, t = !1) {
    const i = this.$(".did");
    if (i.textContent = e, i.classList.toggle("err", t), e) {
      const n = document.createElement("div");
      n.textContent = `${this.$(".said").textContent} → ${e}`, this.$(".log").prepend(n);
    }
  }
  mic(e, t = "") {
    const i = this.$(".mic");
    i.className = `mic ${e}`, i.setAttribute("aria-label", e === "off" ? "Start listening" : e === "talking" ? "Stop talking" : "Stop listening"), this.root.querySelectorAll(".state").forEach((n) => {
      n.className = `state ${n.classList.contains("mstate") ? "mstate " : ""}${e}`, n.textContent !== t && (n.textContent = t);
    });
  }
  level(e) {
    this.$(".mic").style.setProperty("--lvl", String(Math.min(1, e * 12)));
  }
  setWake(e) {
    this.$("input.wake").value = e, this.$(".hf").closest("label").title = `Listens all the time and acts when you start with “${e}”`;
  }
  setPause(e) {
    this.$("select.pause").value = e;
  }
  openSettings() {
    this.root.querySelectorAll("details").forEach((e) => e.open = e.classList.contains("settings"));
  }
  setHandsFree(e) {
    this.$(".hf").checked = e;
  }
  help(e) {
    const t = this.$(".help");
    t.innerHTML = "";
    for (const i of e) {
      const n = document.createElement("li");
      n.textContent = i, t.appendChild(n);
    }
  }
  showNumbers(e) {
    this.badgesOn = e, e ? this.drawBadges(e) : this.$(".badges").innerHTML = "";
  }
  get numbersShown() {
    return !!this.badgesOn;
  }
  drawBadges(e) {
    const t = this.$(".badges");
    t.innerHTML = "";
    for (const i of e) {
      if (!Tt(i.el)) continue;
      const n = i.el.getBoundingClientRect(), o = document.createElement("div");
      o.className = "badge", o.textContent = String(i.num), o.style.left = `${Math.max(2, n.left)}px`, o.style.top = `${Math.max(2, n.top)}px`, t.appendChild(o);
    }
  }
}
const Wt = "https://cdn.jsdelivr.net/npm/kokoro-js@1.2.1/dist/kokoro.web.js", Ht = "onnx-community/Kokoro-82M-v1.0-ONNX", Gt = `
import { KokoroTTS } from '${Wt}';
let tts;
self.onmessage = async ({ data }) => {
  try {
    if (data.type === 'init') {
      tts = await KokoroTTS.from_pretrained('${Ht}', {
        dtype: 'q8',
        device: 'wasm',
        progress_callback: (p) => { if (p.status === 'progress') self.postMessage({ type: 'progress', file: p.file, loaded: p.loaded, total: p.total }); },
      });
      self.postMessage({ type: 'ready' });
    } else if (data.type === 'speak') {
      const out = await tts.generate(data.text, { voice: data.voice, speed: data.speed });
      self.postMessage({ type: 'audio', id: data.id, audio: out.audio, rate: out.sampling_rate }, [out.audio.buffer]);
    }
  } catch (e) {
    self.postMessage({ type: 'error', id: data.id, message: String(e && e.message || e) });
  }
};
`;
function qt(s) {
  const e = s.replace(/\s+/g, " ").trim().match(/[^.!?;:]+[.!?;:]*\s*/g) ?? [s], t = [];
  for (const i of e) {
    const n = i.trim();
    n && (t.length && (t[t.length - 1].length < 40 || n.length < 12) ? t[t.length - 1] += ` ${n}` : t.push(n));
  }
  return t;
}
class Kt {
  constructor() {
    this.rate = 1, this.natural = "off", this.speedFactor = 0, this.onStatus = () => {
    }, this.onTalk = () => {
    }, this.pending = /* @__PURE__ */ new Map(), this.nextId = 1, this.token = 0, this.settled = new Promise((e) => this.settle = e);
  }
  // Load Kokoro the first time reading is asked for (about 86 MB, then cached).
  loadNatural() {
    if (this.natural === "off") {
      this.natural = "loading";
      try {
        const e = URL.createObjectURL(new Blob([Gt], { type: "text/javascript" }));
        this.worker = new Worker(e, { type: "module" });
        const t = {};
        this.worker.onmessage = ({ data: i }) => {
          var n, o;
          if (i.type === "progress") {
            t[i.file] = [i.loaded, i.total];
            const [a, r] = Object.values(t).reduce((c, [h, d]) => [c[0] + h, c[1] + d], [0, 0]);
            r > 5e6 && this.onStatus(`Loading the natural voice… ${Math.round(100 * a / r)}%`);
          } else i.type === "ready" ? this.measure() : i.type === "audio" ? ((n = this.pending.get(i.id)) == null || n({ audio: i.audio, rate: i.rate }), this.pending.delete(i.id)) : i.type === "error" && (i.id ? ((o = this.pending.get(i.id)) == null || o(null), this.pending.delete(i.id)) : (this.natural = "failed", this.settle(), console.warn("[voicenav] natural voice", i.message)));
        }, this.worker.onerror = (i) => {
          this.natural = "failed", this.settle(), console.warn("[voicenav] natural voice worker", i.message);
        }, this.worker.postMessage({ type: "init" });
      } catch {
        this.natural = "failed";
      }
    }
  }
  // Kokoro's speed depends on the device. Time one sample: if it can't keep up
  // with real time, reading would stop between sentences, so use the built-in voice.
  async measure() {
    const e = performance.now(), t = await this.generate("This is how the natural voice sounds when it reads to you."), i = t ? t.audio.length / t.rate : 0;
    this.speedFactor = i ? (performance.now() - e) / 1e3 / i : 99, "speechSynthesis" in window && !speechSynthesis.getVoices().length && await new Promise((o) => {
      speechSynthesis.addEventListener("voiceschanged", () => o(), { once: !0 }), setTimeout(o, 1500);
    });
    const n = "speechSynthesis" in window && speechSynthesis.getVoices().length > 0;
    this.speedFactor <= 1.1 || !n ? (this.natural = "ready", this.onStatus("Natural voice ready")) : (this.natural = "slow", this.onStatus("Using the built-in voice: the natural voice is too slow on this device")), this.settle(), console.info(`[voicenav] natural voice: ${this.speedFactor.toFixed(2)} s per second of speech → ${this.natural}`);
  }
  generate(e) {
    const t = this.nextId++;
    return new Promise((i) => {
      this.pending.set(t, i), this.worker.postMessage({ type: "speak", id: t, text: e, voice: "af_heart", speed: this.rate });
    });
  }
  play(e, t) {
    this.ctx ?? (this.ctx = new AudioContext()), this.ctx.state === "suspended" && this.ctx.resume().catch(() => {
    });
    const i = this.ctx.createBuffer(1, e.audio.length, e.rate);
    return i.copyToChannel(e.audio, 0), new Promise((n) => {
      if (t !== this.token) return n();
      const o = this.ctx.createBufferSource();
      o.buffer = i, o.connect(this.ctx.destination), o.onended = () => n(), this.source = o, o.start();
    });
  }
  browserSay(e, t) {
    return new Promise((i) => {
      if (!("speechSynthesis" in window) || t !== this.token) return i();
      const n = new SpeechSynthesisUtterance(e);
      n.lang = "en-GB", n.rate = this.rate * 1.05, n.onend = () => i(), n.onerror = () => i(), speechSynthesis.speak(n);
    });
  }
  // Speak text sentence by sentence; resolves when done or stopped.
  async speak(e) {
    this.onTalk(!0, e);
    try {
      return await this.speakParts(e);
    } finally {
      this.onTalk(!1, e);
    }
  }
  async speakParts(e) {
    const t = ++this.token;
    "speechSynthesis" in window && speechSynthesis.cancel();
    const i = qt(e);
    if ((!("speechSynthesis" in window) || !speechSynthesis.getVoices().length) && this.natural === "loading" && (await Promise.race([this.settled, new Promise((o) => setTimeout(o, 3e4))]), t !== this.token))
      return !1;
    if (this.natural === "ready") {
      let o = this.generate(i[0]);
      for (let a = 0; a < i.length; a++) {
        const r = await o;
        if (t !== this.token || (a + 1 < i.length && (o = this.generate(i[a + 1])), r ? await this.play(r, t) : await this.browserSay(i[a], t), t !== this.token)) return !1;
      }
      return !0;
    }
    for (const o of i)
      if (await this.browserSay(o, t), t !== this.token) return !1;
    return !0;
  }
  stop() {
    var e;
    this.token++;
    try {
      (e = this.source) == null || e.stop();
    } catch {
    }
    "speechSynthesis" in window && speechSynthesis.cancel();
  }
}
const Jt = "h1,h2,h3,h4,h5,h6,p,li,blockquote,figcaption,dt,dd,td,th,img[alt],[role=img][aria-label],pre", ie = (s) => (s ?? "").replace(/\s+/g, " ").trim();
function st(s) {
  if (s.closest('[hidden],[aria-hidden="true"],[inert]') || s.checkVisibility && !s.checkVisibility({ checkVisibilityCSS: !0 })) return !1;
  const e = s.getBoundingClientRect();
  if (e.width === 0 && e.height === 0) return !1;
  const t = getComputedStyle(s);
  return t.visibility !== "hidden" && t.display !== "none";
}
function Qt(s) {
  const e = document.querySelector("main,[role=main]") ?? document.body, t = [], i = Array.from(e.querySelectorAll(Jt)).filter((n) => !s.contains(n) && st(n));
  for (const n of i) {
    if (n.tagName === "LI" && n.querySelector("p,h1,h2,h3,h4,h5,h6")) continue;
    if (n.tagName === "TD" || n.tagName === "TH") {
      const c = n.closest("tr");
      if (!c || c.firstElementChild !== n) continue;
      const h = Array.from(c.children).map((d) => ie(d.innerText)).filter(Boolean);
      t.push({ el: c, text: h.join(", "), heading: 0, kind: "text" });
      continue;
    }
    const o = /^H([1-6])$/.exec(n.tagName);
    if (o) {
      t.push({ el: n, text: ie(n.innerText), heading: Number(o[1]), kind: "heading" });
      continue;
    }
    const a = n.getAttribute("alt") ?? (n.getAttribute("role") === "img" ? n.getAttribute("aria-label") : null);
    if (a !== null) {
      a.trim() && t.push({ el: n, text: `Image: ${ie(a)}`, heading: 0, kind: "image" });
      continue;
    }
    const r = ie(n.innerText);
    r && t.push({ el: n, text: r, heading: 0, kind: "text" });
  }
  return t;
}
class Xt {
  constructor(e, t, i, n) {
    this.voice = e, this.host = t, this.layer = i, this.onSay = n, this.pos = -1, this.reading = !1, this.list = [];
  }
  refresh() {
    var t;
    const e = (t = this.list[this.pos]) == null ? void 0 : t.el;
    this.list = Qt(this.host), e && (this.pos = this.list.findIndex((i) => i.el === e)), this.pos >= this.list.length && (this.pos = this.list.length - 1);
  }
  mark(e) {
    var n;
    if (!e) {
      (n = this.box) == null || n.remove(), this.box = void 0;
      return;
    }
    const t = e.getBoundingClientRect();
    (t.top < 60 || t.bottom > innerHeight - 60) && e.scrollIntoView({ block: "center", behavior: "instant" });
    const i = e.getBoundingClientRect();
    this.box || (this.box = document.createElement("div"), this.box.className = "reading", this.layer.appendChild(this.box)), Object.assign(this.box.style, { left: `${i.left - 6}px`, top: `${i.top - 4}px`, width: `${i.width + 12}px`, height: `${i.height + 8}px` });
  }
  say(e) {
    return e.kind === "heading" ? `Heading: ${e.text}` : e.text;
  }
  stop() {
    this.reading = !1, this.voice.stop(), this.mark(void 0);
  }
  // Read on from a position until the end, or until the section ends.
  async readFrom(e, t) {
    this.refresh(), this.voice.stop(), this.reading = !0;
    const i = t ?? this.list.length;
    for (let n = Math.max(0, e); n < i && this.reading; n++) {
      this.pos = n;
      const o = this.list[n];
      if (this.mark(o.el), this.onSay(this.say(o)), !await this.voice.speak(this.say(o))) return;
    }
    this.reading && (this.reading = !1, this.mark(void 0));
  }
  readPage() {
    return this.readFrom(0);
  }
  resume() {
    return this.readFrom(this.pos < 0 ? 0 : this.pos);
  }
  // From the heading above where we are, to the next heading of the same or higher level.
  readSection() {
    var n;
    this.refresh();
    let e = this.pos < 0 ? this.list.findIndex((o) => o.heading) : this.pos;
    for (; e > 0 && !this.list[e].heading; ) e--;
    const t = ((n = this.list[e]) == null ? void 0 : n.heading) || 7;
    let i = e + 1;
    for (; i < this.list.length && !(this.list[i].heading && this.list[i].heading <= t); ) i++;
    return this.readFrom(e, i);
  }
  // Move by heading, paragraph or link and say what is there.
  async move(e, t) {
    if (this.stop(), this.refresh(), e === "link") return this.moveLink(t);
    let i = this.pos;
    for (; ; ) {
      if (i += t, i < 0 || i >= this.list.length) return t > 0 ? `No more ${e}s below.` : `No more ${e}s above.`;
      if (e === "paragraph" || this.list[i].heading) break;
    }
    this.pos = i;
    const n = this.list[i];
    this.mark(n.el);
    const o = this.say(n);
    return this.onSay(o), await this.voice.speak(o), "";
  }
  async moveLink(e) {
    var r;
    const t = Array.from(document.querySelectorAll("a[href]")).filter((c) => !this.host.contains(c) && st(c)), i = ((r = this.list[this.pos]) == null ? void 0 : r.el) ?? document.activeElement;
    let n;
    if (document.activeElement instanceof HTMLAnchorElement && t.includes(document.activeElement))
      n = t.indexOf(document.activeElement) + e;
    else if (i && i !== document.body) {
      const c = t.findIndex((h) => i.compareDocumentPosition(h) & Node.DOCUMENT_POSITION_FOLLOWING);
      n = e > 0 ? c < 0 ? t.length : c : (c < 0 ? t.length : c) - 1;
    } else n = e > 0 ? 0 : t.length - 1;
    const o = t[n];
    if (!o) return e > 0 ? "No more links below." : "No more links above.";
    o.focus(), this.mark(o);
    const a = `Link: ${ie(o.getAttribute("aria-label") || o.innerText || o.title)}`;
    return this.onSay(a), await this.voice.speak(a), "";
  }
  headings() {
    this.refresh();
    const e = this.list.filter((t) => t.heading);
    return e.length ? `${e.length} heading${e.length === 1 ? "" : "s"}: ${e.map((t) => t.text).join(". ")}` : "This page has no headings.";
  }
  where() {
    var n, o;
    this.refresh();
    let e = this.pos;
    for (; e > 0 && !((n = this.list[e]) != null && n.heading); ) e--;
    const t = this.pos >= 0 && ((o = this.list[e]) != null && o.heading) ? ` You are in the section ${this.list[e].text}.` : "", i = this.pos >= 0 ? ` At item ${this.pos + 1} of ${this.list.length}.` : "";
    return `${document.title}.${t}${i}`;
  }
  faster(e) {
    return this.voice.rate = Math.min(1.8, Math.max(0.6, Math.round((this.voice.rate + e * 0.15) * 100) / 100)), this.voice.rate;
  }
}
function Fe(s) {
  const e = s.trim().split(":").map(Number);
  return e.length === 3 ? e[0] * 3600 + e[1] * 60 + e[2] : e[0] * 60 + e[1];
}
function Yt(s) {
  const e = [];
  for (const t of s.replace(/\r/g, "").split(/\n\n+/)) {
    const i = t.split(`
`), n = i.findIndex((c) => c.includes("-->"));
    if (n < 0) continue;
    const [o, a] = i[n].split("-->"), r = i.slice(n + 1).join(" ").replace(/<[^>]+>/g, "").trim();
    r && e.push({ start: Fe(o), end: Fe(a.trim().split(/\s/)[0]), text: r });
  }
  return e;
}
async function Be(s) {
  var n, o;
  const e = s.querySelector("track[kind=captions],track[kind=subtitles],track"), t = (e == null ? void 0 : e.src) || ((n = document.querySelector('a[href$=".vtt"]')) == null ? void 0 : n.href) || ((o = document.querySelector('link[href$=".vtt"]')) == null ? void 0 : o.href);
  if (!t) return [];
  const i = await fetch(t);
  return i.ok ? Yt(await i.text()) : [];
}
class Zt {
  constructor(e, t) {
    this.voice = e, this.onSay = t, this.active = !1, this.cues = [], this.last = -1, this.speaking = !1, this.waiting = !1, this.onTime = () => this.tick(), this.onPause = () => {
      this.waiting || (this.voice.stop(), this.speaking = !1, this.last = this.index(this.video.currentTime) - 1);
    }, this.onPlay = () => this.tick(), this.onSeek = () => {
      const i = this.video;
      this.voice.stop(), this.speaking = !1, this.waiting && (this.waiting = !1, i.play().catch(() => {
      })), this.last = this.index(i.currentTime) - 1, this.tick();
    };
  }
  async start() {
    const e = document.querySelector("video");
    if (!e) return "There is no video on this page.";
    const t = await Be(e);
    return t.length ? (this.stop(), this.video = e, this.cues = t, this.active = !0, this.last = this.index(e.currentTime) - 1, e.addEventListener("timeupdate", this.onTime), e.addEventListener("seeked", this.onSeek), e.addEventListener("pause", this.onPause), e.addEventListener("play", this.onPlay), e.muted = !1, await e.play().catch(() => {
    }), this.tick(), "") : "This video has no transcript I can read.";
  }
  stop() {
    this.video && (this.video.removeEventListener("timeupdate", this.onTime), this.video.removeEventListener("seeked", this.onSeek), this.video.removeEventListener("pause", this.onPause), this.video.removeEventListener("play", this.onPlay), this.active && !this.video.paused && (this.waiting = !0, this.video.pause()), this.voice.stop(), this.active = !1, this.speaking = !1, this.waiting = !1);
  }
  // Narrate whenever the video is played, without being asked (guide pages).
  async auto() {
    const e = document.querySelector("video");
    if (!e) return;
    const t = async () => {
      if (this.active) return;
      this.voice.loadNatural();
      const i = await Be(e);
      i.length && (this.video = e, this.cues = i, this.active = !0, this.last = this.index(e.currentTime) - 1, e.addEventListener("timeupdate", this.onTime), e.addEventListener("seeked", this.onSeek), e.addEventListener("pause", this.onPause), e.addEventListener("play", this.onPlay), this.tick());
    };
    e.addEventListener("play", t), e.paused || t();
  }
  // Narrating right now: talking, or the video playing with lines to come.
  get busy() {
    return this.active && (this.speaking || !!this.video && !this.video.paused);
  }
  // The line playing at time t (or the last one before it).
  index(e) {
    let t = 0;
    for (; t < this.cues.length && this.cues[t].start <= e + 0.05; ) t++;
    return Math.max(0, t - 1);
  }
  tick() {
    if (!this.active || !this.video) return;
    const e = this.video, t = this.index(e.currentTime);
    if (this.speaking) {
      t > this.last && !e.paused && (e.pause(), this.waiting = !0);
      return;
    }
    t > this.last && this.say(this.last + 1);
  }
  async say(e) {
    const t = this.cues[e], i = this.video;
    if (!t || !i) return;
    this.last = e, this.speaking = !0, this.onSay(t.text);
    const n = await this.voice.speak(t.text);
    if (this.speaking = !1, !(!this.active || !n)) {
      if (this.index(i.currentTime) > this.last) return this.say(this.last + 1);
      this.waiting && (this.waiting = !1, i.play().catch(() => {
      }));
    }
  }
}
const _ = (s) => (s ?? "").replace(/\s+/g, " ").trim();
function P(s) {
  const e = s.tagName.toLowerCase(), t = _(s.innerText).slice(0, 50), i = s.id ? `#${s.id}` : "", n = typeof s.className == "string" && s.className ? `.${s.className.trim().split(/\s+/)[0]}` : "";
  return `<${e}${i || n}>${t ? ` “${t}”` : ""}`;
}
function ce(s) {
  if (s.closest('[hidden],[aria-hidden="true"]') || s.checkVisibility && !s.checkVisibility({ checkVisibilityCSS: !0, contentVisibilityAuto: !0 })) return !1;
  const e = s.getBoundingClientRect(), t = getComputedStyle(s);
  return e.width > 0 && e.height > 0 && t.visibility !== "hidden" && t.display !== "none";
}
function We([s, e, t]) {
  const i = [s, e, t].map((n) => (n /= 255, n <= 0.03928 ? n / 12.92 : ((n + 0.055) / 1.055) ** 2.4));
  return 0.2126 * i[0] + 0.7152 * i[1] + 0.0722 * i[2];
}
function nt(s) {
  const e = s.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?\)/);
  return !e || e[4] !== void 0 && Number(e[4]) < 0.5 ? null : [Number(e[1]), Number(e[2]), Number(e[3])];
}
function ei(s) {
  for (let e = s; e; e = e.parentElement) {
    const t = getComputedStyle(e);
    if (t.backgroundImage !== "none") return [];
    const i = nt(t.backgroundColor);
    if (i) return i;
  }
  return [255, 255, 255];
}
function ti(s) {
  var h, d;
  const e = [], t = (l) => e.push(l), i = (l) => s.contains(l);
  _(document.title) || t({ rule: "Page has no title", wcag: "2.4.2", severity: "serious", what: "the page", fix: "Give the page a <title> that says what it is." }), document.documentElement.lang || t({ rule: "Page language not set", wcag: "3.1.1", severity: "moderate", what: "<html>", fix: 'Add lang="en" (or the page language) to <html>, so voices read it correctly.' });
  const n = Array.from(document.querySelectorAll("h1,h2,h3,h4,h5,h6")).filter((l) => !i(l) && ce(l));
  n.some((l) => l.tagName === "H1") || t({ rule: "No main heading", wcag: "1.3.1", severity: "moderate", what: "the page", fix: "Add one <h1> naming the page; people jump to it to find out where they are." });
  let o = 0;
  for (const l of n) {
    const f = Number(l.tagName[1]);
    o && f > o + 1 && t({ rule: `Heading jumps from level ${o} to ${f}`, wcag: "1.3.1", severity: "minor", what: P(l), fix: `Use <h${o + 1}> here, or add the missing level, so the outline makes sense when read aloud.`, el: l }), o = f;
  }
  const a = Array.from(document.querySelectorAll("a[href],button,input:not([type=hidden]),select,textarea,[role=button],[role=link],[role=checkbox],[role=tab],[role=switch]")).filter((l) => !i(l) && ce(l));
  for (const l of a) {
    const f = tt(l), g = l.tagName, m = g === "INPUT" || g === "SELECT" || g === "TEXTAREA";
    if (!f) {
      t({ rule: m ? "Form field has no label" : "Control has no name", wcag: m ? "1.3.1, 4.1.2" : "4.1.2", severity: "serious", what: P(l), fix: m ? "Add a <label> for it, or aria-label. Voice users can only fill fields they can name." : "Give it text, or aria-label if it shows only an icon. Nobody can say “click” on a button without a name.", el: l });
      continue;
    }
    m && !((h = l.labels) != null && h.length) && !l.getAttribute("aria-label") && !l.getAttribute("aria-labelledby") && l.getAttribute("placeholder") && t({ rule: "Field labelled only by its placeholder", wcag: "3.3.2", severity: "moderate", what: P(l), fix: "Add a visible <label>. The placeholder disappears as soon as someone starts typing.", el: l });
    const v = l.getAttribute("aria-label"), y = _(l.innerText).toLowerCase();
    v && y && !v.toLowerCase().includes(y) && t({ rule: "Visible text missing from the accessible name", wcag: "2.5.3", severity: "serious", what: P(l), fix: `Its aria-label “${v}” doesn't contain “${_(l.innerText)}”. Start the aria-label with the visible words, so saying what you see works.`, el: l }), g === "A" && /^(click here|here|read more|more|details|link|this)$/i.test(f) && t({ rule: "Link text says nothing on its own", wcag: "2.4.4", severity: "minor", what: P(l), fix: `“${f}” makes no sense read out in a list of links. Say where it goes, e.g. “Details of Rice 5kg”.`, el: l });
    const b = l.getBoundingClientRect(), u = g === "A" && _((d = l.parentElement) == null ? void 0 : d.innerText).length > _(l.innerText).length + 3;
    !m && (b.width < 24 || b.height < 24) && !u && t({ rule: "Target smaller than 24 × 24 pixels", wcag: "2.5.8", severity: "moderate", what: P(l), fix: `It is ${Math.round(b.width)} × ${Math.round(b.height)} px. Make it at least 24 × 24 so shaky hands and switch users can hit it.`, el: l }), Number(l.getAttribute("tabindex")) > 0 && t({ rule: "Positive tabindex changes the keyboard order", wcag: "2.4.3", severity: "minor", what: P(l), fix: "Remove tabindex (or use 0) and put the element where it belongs in the page order.", el: l });
  }
  for (const l of Array.from(document.images))
    i(l) || !ce(l) || l.hasAttribute("alt") || t({ rule: "Image has no alt text", wcag: "1.1.1", severity: "serious", what: P(l) + ` ${l.src.split("/").pop()}`, fix: 'Add alt="…" describing what matters in the picture, or alt="" if it is only decoration.', el: l });
  const r = /* @__PURE__ */ new Set(), c = Array.from(document.querySelectorAll("p,li,a,button,label,span,h1,h2,h3,h4,h5,h6,td,th,small")).filter((l) => !i(l) && ce(l) && _(l.innerText) && Array.from(l.childNodes).some((f) => f.nodeType === 3 && _(f.textContent))).slice(0, 400);
  for (const l of c) {
    if (l.closest('[disabled],[aria-disabled="true"],[class*="logo"],[id*="logo"]')) continue;
    const f = getComputedStyle(l), g = nt(f.color), m = ei(l);
    if (!g || !m.length) continue;
    const [v, y] = [We(g), We(m)].sort((O, N) => N - O), b = (v + 0.05) / (y + 0.05), u = parseFloat(f.fontSize), $ = u >= 24 || u >= 18.66 && Number(f.fontWeight) >= 700 ? 3 : 4.5, E = `${f.color}|${m.join(",")}`;
    b < $ && !r.has(E) && (r.add(E), t({ rule: `Text contrast ${b.toFixed(1)}:1 (needs ${$}:1)`, wcag: "1.4.3", severity: b < 3 ? "serious" : "moderate", what: P(l), fix: `Darken the text or lighten the background (text ${f.color} on rgb(${m.join(", ")})).`, el: l }));
  }
  return e;
}
function ot(s) {
  if (!s.length) return "I found no problems on this page.";
  const e = s.filter((t) => t.severity === "serious").length;
  return `I found ${s.length} problem${s.length === 1 ? "" : "s"}${e ? `, ${e} serious` : ""}. The report is downloading.`;
}
function ii(s) {
  const e = (r) => r.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]), t = (/* @__PURE__ */ new Date()).toISOString().slice(0, 16).replace("T", " "), i = s.map((r) => `<tr><td>${r.severity}</td><td>${e(r.rule)}</td><td>${r.wcag}</td><td><code>${e(r.what)}</code></td><td>${e(r.fix)}</td></tr>`).join(""), n = s.map(({ el: r, ...c }) => c), o = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Accessibility check: ${e(document.title)}</title>
<style>body{font:15px/1.5 system-ui,sans-serif;max-width:1100px;margin:32px auto;padding:0 16px;color:#1d1440}
table{border-collapse:collapse;width:100%}th,td{text-align:left;padding:8px;border-bottom:1px solid #ddd;vertical-align:top}
th{background:#f4f1ff}code{font-size:13px}</style></head><body>
<h1>Accessibility check</h1>
<p><strong>${e(document.title)}</strong>, ${e(location.href)}<br>Checked ${t} by Wezesha voice control. ${e(ot(s).replace(" The report is downloading.", ""))}</p>
<p>These are the checks a voice-control tool can do on its own. A full audit also needs people who use screen readers, switches and voice to try the page.</p>
<table><thead><tr><th>Severity</th><th>Problem</th><th>WCAG</th><th>Where</th><th>How to fix</th></tr></thead><tbody>${i || '<tr><td colspan="5">No problems found.</td></tr>'}</tbody></table>
<script type="application/json" id="findings">${e(JSON.stringify({ url: location.href, checked: t, findings: n }))}<\/script>
</body></html>`, a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([o], { type: "text/html" })), a.download = `accessibility-check-${location.hostname || "page"}-${t.slice(0, 10)}.html`, document.body.appendChild(a), a.click(), a.remove(), setTimeout(() => URL.revokeObjectURL(a.href), 5e3);
}
const si = /\b(pay|checkout|check out|place order|buy|delete|remove|send|submit|transfer|empty cart|cancel order|sign out|log out)\b/i, x = {
  get(s) {
    try {
      return localStorage.getItem(`voicenav:${s}`);
    } catch {
      return null;
    }
  },
  set(s, e) {
    try {
      localStorage.setItem(`voicenav:${s}`, e);
    } catch {
    }
  }
}, He = 15e3, ni = typeof matchMedia == "function" && matchMedia("(pointer: coarse)").matches, $e = ni ? "Tap the mic" : "Press the mic, or Alt+V", fe = (s) => {
  var e;
  return (e = document.querySelector(`meta[name="${s}"]`)) == null ? void 0 : e.content;
};
let R = [], ue = /$^/;
function rt(s) {
  R = s.split(",").map((t) => t.trim().toLowerCase()).filter(Boolean);
  const e = R.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+")).join("|");
  ue = new RegExp(`^\\W*(?:(?:hey|hi|ok|okay|hello)[\\s,]+)?(?:${e})\\b[\\s,.!:;-]*`, "i");
}
rt(x.get("wake") || fe("voicenav-wake") || "computer, kompyuta, compute her");
const le = { short: 40, medium: 70, long: 110 };
function oi() {
  const s = document.querySelector('meta[name="voicenav-assets"]');
  if (s != null && s.content) return new URL(s.content, location.href);
  const e = import.meta.url;
  return new URL("./", e);
}
async function ri(s) {
  const e = new URL("worker.js", s);
  if (e.origin === location.origin) return e.href;
  const t = await (await fetch(e)).text();
  return URL.createObjectURL(new Blob([t], { type: "text/javascript" }));
}
const Ee = (s) => s.match(/\d{2,}/g) ?? [];
function Se(s, e) {
  const t = Ee(e), i = Ee(s);
  return !t.length || !i.length || i.some((n) => t.includes(n));
}
const j = (s) => I(s).split(" ").filter((e) => e.length > 2).map((e) => e.replace(/s$/, ""));
class ai {
  constructor() {
    this.appTools = {}, this.targets = [], this.ready = !1, this.busy = !1, this.speakOn = x.get("speak") !== "0", this.handsFree = x.get("handsfree") === "1", this.voice = new Kt(), this.lang = fe("voicenav-lang") || "en", this._awake = Number(x.get("awake") || 0), this.loading = !1, this.hearing = !1, this.warmedKey = "", this.scanAt = -1, this.lastPress = 0, this.talkingUntil = 0, this.talkStart = 0, this.talkEnd = 0, this.recentSpeech = [], this.panel = new Bt(
      {
        onMic: () => this.toggle(),
        onTyped: (e) => this.handle(e),
        onHandsFree: (e) => this.setHandsFree(e),
        onMinimize: (e) => this.minimize(e),
        onWake: (e) => this.setWakeWord(e),
        onPause: (e) => this.setPause(e),
        onSwitchKey: (e) => {
          x.set("switchKey", e), this.reply(e ? `Switch key set to ${e}` : "Switch key off");
        },
        onScan: (e) => {
          x.set("scan", e ? "1" : ""), this.scanAt = -1, this.reply(e ? "Switch scanning on: press your switch to move, press twice quickly to choose." : "Switch scanning off");
        },
        onSpeak: (e) => {
          this.speakOn = e, x.set("speak", e ? "1" : "0"), e || speechSynthesis.cancel();
        }
      },
      {
        handsFree: this.handsFree,
        speak: this.speakOn,
        minimized: x.get("min") === "1",
        wake: R[0],
        pause: x.get("pause") || "short",
        switchKey: x.get("switchKey") || "",
        scan: x.get("scan") === "1"
      }
    ), this.mic = new zt(
      (e) => this.heard(e),
      (e, t) => {
        this.panel.level(e), this.hearing = t, this.showState();
      }
    ), this.voice.rate = Number(x.get("rate")) || 1, this.mic.quietBlocks = le[x.get("pause") || "short"] ?? 40, this.voice.onTalk = (e, t) => {
      e ? (this.talkStart = Date.now(), this.recentSpeech.push({ text: t, at: Date.now() })) : this.talkEnd = Date.now(), this.recentSpeech = this.recentSpeech.filter((i) => Date.now() - i.at < 3e4), this.showState();
    }, setInterval(() => this.showState(), 500), this.voice.onStatus = (e) => {
      this.busy || this.panel.status(e);
    }, this.narrator = new Zt(this.voice, (e) => this.panel.did(e)), this.panel.menuPick = (e) => this.pickMenu(e), this.panel.menuNav = (e) => this.runQuick({ do: "menu", act: e }), setTimeout(() => {
      (!("speechSynthesis" in window) || !speechSynthesis.getVoices().length) && this.speakOn && this.voice.loadNatural();
    }, 1600), this.reader = new Xt(this.voice, this.panel.host, this.panel.root, (e) => this.panel.did(e)), addEventListener("keydown", (e) => this.onSwitch(e), !0), addEventListener("keydown", (e) => {
      if (e.key === "Escape" && this.talking && (this.hush(), this.panel.did("Stopped")), e.key === "Escape" && this.panel.menuOpen) {
        this.menu = void 0, this.panel.hideMenu();
        return;
      }
      e.key === "Escape" && this.reader.reading && (this.reader.stop(), this.panel.did("Stopped reading")), e.altKey && e.code === "KeyV" && (e.preventDefault(), this.toggle()), e.altKey && e.code === "KeyN" && (e.preventDefault(), this.numbers(!this.panel.numbersShown));
    });
  }
  get awakeUntil() {
    return this._awake;
  }
  set awakeUntil(e) {
    this._awake = e, x.set("awake", String(e));
  }
  autoNarrate() {
    this.narrator.auto();
  }
  // Lazy page: small panel, models load on first use.
  idle() {
    x.get("min") === null && this.panel.minimize(!0), this.panel.status("Press the mic to talk to it. Video narration is on."), this.showState();
  }
  register(e, t) {
    this.appTools[e] = t;
  }
  unregister(e) {
    delete this.appTools[e];
  }
  async load() {
    var a;
    if (this.loading || this.ready) return;
    this.loading = !0;
    const e = oi(), [t, i] = [await ri(e), new URL("needle.wasm", e).href], n = { speech: 0, actions: 0 }, o = () => this.panel.status(`Getting ready… ${Math.round((n.speech + n.actions) / 2)}%`);
    o();
    try {
      this.whistle = new vt({
        workerUrl: t,
        wasmUrl: i,
        onDownloadProgress: (r) => (n.speech = r.percentage ?? 0, o())
      }), this.needle = new kt({
        workerUrl: t,
        wasmUrl: i,
        stateless: !0,
        onDownloadProgress: (r) => (n.actions = r.percentage ?? 0, o())
      }), await Promise.all([
        this.whistle.transcribe(new Float32Array(1600), { language: this.lang }),
        // Read this page's tools now, so "Ready" also means the first command is quick.
        this.needle.generate({ prompt: "scroll down", tools: (this.targets = U(this.panel.host), this.toolsForPage()), maxOutputTokens: 128 }).catch(() => {
        })
        // only a warm-up; its answer doesn't matter
      ]), this.warmedKey = ((a = this.toolCache) == null ? void 0 : a.key) ?? "", this.ready = !0, this.refresh(), this.watchPage(), this.handsFree && this.awake && this.wakeUp(!0), this.panel.status(this.handsFree ? this.idleStatus() : `Ready. ${$e}.`), this.handsFree && await this.listen();
    } catch (r) {
      this.panel.status(`Could not start: ${(r == null ? void 0 : r.message) ?? r}`), console.error("[voicenav]", r);
    }
  }
  refresh() {
    this.targets = U(this.panel.host);
    const e = [
      `With “Keep listening” on, start with “${R[0]}”: “${R[0]}, scroll down”. It then listens for 15 seconds without it.`,
      "“show numbers”, then “number 3”",
      "“scroll down”, “go back”, “read the page”"
    ], t = this.targets.find((a) => a.kind === "link"), i = this.targets.find((a) => a.kind === "field"), n = this.targets.find((a) => a.item), o = this.targets.find((a) => a.kind === "button" && !a.item);
    t && e.push(`“open ${t.name}”`), o && e.push(`“${o.name}”`), i && e.push(`“type … in ${i.name}”`), n && e.push(`“${n.action} ${n.item}”`);
    for (const [a, r] of Object.entries(this.appTools)) e.push(`${r.description} (${a})`);
    document.querySelector("video") && e.push("“narrate the video”: speaks the video’s transcript as it plays"), e.push("“menu”: a numbered list of what you can do here; then say the number"), e.push("“drag the microphone up a bit”, “move the microphone to the top left”; or drag it by hand"), e.push("“minimize” makes this panel small; “expand” opens it again"), e.push("“check this page”: an accessibility report for the site owner"), e.push("“go to sleep” (waits for the wake word again), “stop listening” (mic off)"), this.panel.help(e);
  }
  async toggle() {
    this.talking && (this.hush(), this.panel.did("Stopped"), this.mic.running) || (this.mic.running ? (this.mic.stop(), this.showState(), this.panel.status("Not listening. Press the mic to start.")) : await this.listen());
  }
  setHandsFree(e) {
    this.handsFree = e, x.set("handsfree", e ? "1" : ""), this.panel.setHandsFree(e), e && !this.mic.running && this.listen();
  }
  async listen() {
    if (!this.ready && !this.loading && await this.load(), !this.ready) return this.panel.status("Still getting ready…");
    try {
      await this.mic.start(), this.showState(), this.panel.status(this.handsFree ? this.awake ? "Awake. Say what to do." : this.idleStatus() : "Listening…");
    } catch (e) {
      this.panel.status(`No microphone: ${(e == null ? void 0 : e.message) ?? e}`);
    }
  }
  async heard(e) {
    if (!this.whistle || this.busy) return;
    this.busy = !0, this.showState(), this.panel.status("Working it out…");
    let t = !1;
    try {
      this.targets = U(this.panel.host);
      const i = [R[0], ...this.targets.map((c) => c.item ?? c.name).filter((c) => c.length < 30)].slice(0, 40), o = (await this.whistle.transcribe(e, { language: this.lang, keywords: i })).text.trim();
      if (!o) return;
      const a = this.isOwnVoice(o, e.startedAt);
      if (this.talking || a) {
        const c = I(o).split(" ").slice(-3).join(" ");
        if (/\b(stop|quiet|enough|shut up|pause|be quiet|stop talking|stop reading)\b/.test(c)) {
          this.hush(), this.panel.did("Stopped");
          return;
        }
        if (!ue.test(o)) {
          this.handsFree && this.panel.status(this.awake ? "Awake. Say what to do." : this.idleStatus());
          return;
        }
      }
      if (this.panel.heard(o), !this.handsFree) {
        const c = o.match(ue), h = c ? o.slice(c[0].length).trim() : o;
        if (!h) {
          this.panel.said(o), this.reply("Yes? Say what to do."), t = !0;
          return;
        }
        await this.handle(h), (this.pending || this.menu) && (t = !0);
        return;
      }
      const r = o.match(ue);
      if (r) {
        this.reader.stop();
        const c = o.slice(r[0].length).trim();
        if (this.wakeUp(), !c) {
          this.panel.said(o), this.panel.did("Yes? Say what to do.");
          return;
        }
        await this.handle(c, !0);
      } else if (this.awake && !this.reader.reading)
        await this.handle(o, !0);
      else {
        const c = /\b(password|passcode|pin)\b/i.test(o) ? "something" : `“${o.slice(0, 40)}”`;
        this.panel.status(`Ignored ${c}. Say “${R[0]}” first.`);
        return;
      }
      this.awakeUntil && (this.awakeUntil = Date.now() + He);
    } catch (i) {
      this.panel.did(`Error: ${(i == null ? void 0 : i.message) ?? i}`, !0);
    } finally {
      if (this.busy = !1, !this.handsFree && this.mic.running && t)
        this.panel.status("Listening…");
      else if (!this.handsFree && this.mic.running && this.talking) {
        this.panel.status("Talking. Say “stop” to stop.");
        const i = setInterval(() => {
          this.talking || this.busy || (clearInterval(i), !this.handsFree && this.mic.running && !this.pending && !this.menu && (this.mic.stop(), this.showState(), this.panel.status(`${$e} to say something else.`)));
        }, 300);
      } else !this.handsFree && this.mic.running && (this.mic.stop(), this.panel.status(`${$e} to say something else.`));
      this.showState();
    }
  }
  showState() {
    var n;
    const e = Math.max(0, Math.ceil((this.awakeUntil - Date.now()) / 1e3)), [t, i] = (n = this.mic) != null && n.running ? this.talking ? ["talking", "Talking · say “stop”"] : this.busy ? ["busy", "Working…"] : this.hearing ? ["hearing", "Hearing you"] : this.handsFree ? this.awake ? ["awake", `Speak now · ${e} s`] : ["sleep", `Say “${R[0]}” first`] : ["on", "Listening"] : ["off", "Mic off"];
    this.panel.mic(t, i);
  }
  get awake() {
    return Date.now() < this.awakeUntil;
  }
  idleStatus() {
    return `Listening for “${R[0]}”…`;
  }
  // A short rising tone tells someone who can't see the screen that it heard them.
  wakeUp(e = !1) {
    const t = !this.awake && !e;
    this.awakeUntil = Date.now() + He, this.showState(), this.panel.status("Awake. Say what to do."), clearTimeout(this.sleepTimer);
    const i = () => {
      if (this.awake) return void (this.sleepTimer = setTimeout(i, 500));
      this.mic.running && this.handsFree && (this.showState(), this.panel.status(this.idleStatus()));
    };
    this.sleepTimer = setTimeout(i, 500), t && ci();
  }
  // strict: spoken in keep-listening mode, so never guess. Only phrases and
  // model calls that clearly match run; no loose "nearest button" fallback.
  async handle(e, t = !1) {
    if (!this.ready && !this.loading && this.load(), /\b(password|passcode|pass code|pin|secret code)\b/i.test(e) && /\b(is|type|enter|write|put|fill)\b/i.test(e))
      return this.panel.said("(hidden)"), this.reply("I never type passwords by voice, because people nearby would hear them. Say “sign in with a passkey”, or use your password manager.", !0);
    if (this.panel.said(e), this.targets = U(this.panel.host), this.menu && this.panel.menuOpen) {
      const u = it(I(e).replace(/^(number|option|item)\s+/, ""));
      if (u) return this.pickMenu(u);
    }
    const i = Nt(e), n = this.dictating;
    if (n && (!n.el.isConnected || document.activeElement !== n.el) && (this.dictating = void 0), this.dictating && /^(done|finished|stop (typing|dictating)|that's all)$/i.test(I(e)))
      return this.dictating = void 0, this.reply("Done typing");
    const o = this.targets.some((u) => {
      var w;
      return u.el !== ((w = this.dictating) == null ? void 0 : w.el) && I(u.name) === je(e);
    });
    if (this.dictating && !i && !o && !/^(click|press|tap|open|go to|go back|show|choose|select|type|scroll|read)\b/i.test(I(e))) {
      const u = B(this.dictating, e, !0);
      return this.reply(`Typed “${u}”`);
    }
    if (i && this.runQuick(i) !== !1) return;
    this.dictating = void 0;
    const a = je(e), r = this.targets.find((u) => I(u.name) === a || I(u.item ?? "") === a);
    if (r && !r.item) return this.clickTarget(r);
    const c = this.itemByWords(e);
    if (c) return this.clickTarget(c);
    if (!this.needle) return this.reply("Still getting ready.", !0);
    const d = this.toolsForPage();
    let l = [];
    const f = Object.entries(this.appTools).filter(([, u]) => (u.triggers ?? []).some((w) => new RegExp(w, "i").test(e))), g = [];
    f.length && g.push(Object.fromEntries(f.map(([u, w]) => [u, { description: w.description, inputSchema: w.inputSchema, triggers: w.triggers }]))), g.push(d);
    let m = g.shift();
    for (let u = 0; u < 3 && !l.length && Object.keys(m).length; u++)
      try {
        const w = await this.needle.generate({ prompt: e, tools: m, maxOutputTokens: 256 });
        let $ = w.toolCalls;
        const E = w.raw.validation ?? {};
        if (!$.length && !E.negation && !(E.ungrounded ?? []).length ? $ = w.suppressedToolCalls.map((N) => this.regrounded(N, e, m)).filter((N) => this.grounded(N, e)) : $ = $.map((N) => this.regrounded(N, e, m)), E.negation) break;
        const O = $.filter((N) => !Object.values(N.input ?? {}).every((oe) => typeof oe != "string" || Se(oe, e)));
        if (l = $.filter((N) => !O.includes(N)), console.debug("[voicenav]", e, w), l.length) break;
        if (!O.length) {
          if (!g.length) break;
          m = g.shift();
          continue;
        }
        m = Object.fromEntries(Object.entries(m).filter(([N]) => !O.some((oe) => oe.toolName === N)));
      } catch (w) {
        console.warn("[voicenav] model", w);
        break;
      }
    if (l.length) {
      for (const u of l)
        await this.runCall(u), this.targets = U(this.panel.host);
      return;
    }
    if (t) return this.reply("I didn’t get that. Say “menu” to see what you can do here.", !0);
    const v = this.targets.find((u) => u.el === document.activeElement && u.kind === "field");
    if (v) {
      const u = B(v, e, !0);
      return this.reply(`Typed “${u}” into ${v.name}`);
    }
    const y = K(this.targets, a);
    if (y && a.length > 2 && Se(y.name, e)) return this.clickTarget(y);
    const b = Ee(e)[0];
    if (b) return this.reply(`I can't see ${b} on this page.`, !0);
    this.reply("I didn’t get that. Say “menu” to see what you can do here.", !0);
  }
  // When the page settles after a change, read the new tools in the background
  // so the next command doesn't pay for it.
  watchPage() {
    new MutationObserver((t) => {
      t.every((i) => this.panel.host.contains(i.target) || i.target === this.panel.host) || (clearTimeout(this.warmTimer), this.warmTimer = setTimeout(() => this.warm(), 700));
    }).observe(document.body, { subtree: !0, childList: !0, attributes: !0, attributeFilter: ["hidden", "disabled", "aria-hidden", "aria-label"] }), this.warm();
  }
  warm() {
    if (!this.needle || !this.ready || this.busy) return;
    this.targets = U(this.panel.host);
    const e = this.toolsForPage();
    this.toolCache.key !== this.warmedKey && (this.warmedKey = this.toolCache.key, this.needle.generate({ prompt: "scroll down", tools: e, maxOutputTokens: 128 }).catch(() => {
    }));
  }
  toolsForPage() {
    var n;
    const e = Et(this.targets, this.appTools);
    delete e.scroll_page, delete e.read_aloud;
    const t = [...new Set(this.targets.map((o) => o.action).filter(Boolean))];
    if (e.item_action && t.length) {
      const o = [...new Set(t.map((a) => I(a).split(" ")[0]))].join("|");
      e.item_action.triggers = [`^(?![\\s\\S]*\\b(and|then)\\b)\\s*(${o})\\b`];
    }
    const i = JSON.stringify(e);
    return ((n = this.toolCache) == null ? void 0 : n.key) !== i && (this.toolCache = { key: i, tools: e }), this.toolCache.tools;
  }
  itemByWords(e) {
    const t = new Set(j(e)), i = (r) => j(r ?? "").filter((c) => t.has(c)).length;
    let n, o = 0, a = !1;
    for (const r of this.targets) {
      if (!r.item || !r.action) continue;
      const c = i(r.action), h = i(r.item);
      if (!c || !h || !Se(r.item, e)) continue;
      const d = c * 10 + h;
      d > o ? (n = r, o = d, a = !1) : d === o && (a = !0);
    }
    return a ? void 0 : n;
  }
  grounded(e, t) {
    const i = new Set(j(t));
    return Object.values(e.input).every((n) => {
      if (typeof n != "string") return !0;
      const o = j(n);
      return o.length === 0 || o.some((a) => i.has(a));
    });
  }
  // The model sometimes picks a valid value the person never said ("Message"
  // for "my name is…"). If another allowed value matches their words, use it.
  regrounded(e, t, i) {
    var d, l, f;
    const n = ((l = (d = i[e.toolName]) == null ? void 0 : d.inputSchema) == null ? void 0 : l.properties) ?? {}, o = new Set(j(t)), a = (g) => j(g).filter((m) => o.has(m)).length, r = { ...e.input }, c = ` ${I(t).replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ")} `, h = (g) => ` ${I(g).replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim()} `;
    for (const [g, m] of Object.entries(r)) {
      const v = (f = n[g]) == null ? void 0 : f.enum;
      if (typeof m != "string" || !v) continue;
      const y = v.filter((u) => c.includes(h(u))).sort((u, w) => w.length - u.length)[0];
      if (y && !c.includes(h(m))) {
        r[g] = y;
        continue;
      }
      const b = v.map((u) => [u, a(u)]).sort((u, w) => w[1] - u[1])[0];
      b && b[1] > a(m) && (r[g] = b[0]);
    }
    return { ...e, input: r };
  }
  find(e, t) {
    const i = t ? this.targets.filter((n) => t.includes(n.kind)) : this.targets;
    return i.find((n) => n.name === e) ?? K(i, e);
  }
  async runCall(e) {
    const t = e.input ?? {};
    switch (e.toolName) {
      case "click": {
        const i = this.find(String(t.target));
        return i ? this.clickTarget(i) : this.reply(`I can't see ${t.target}.`, !0);
      }
      case "item_action": {
        const i = this.targets.filter((o) => o.item), n = i.find((o) => o.item === t.item && o.action === t.action) ?? K(i, `${t.action} ${t.item}`);
        return n ? this.clickTarget(n) : this.reply(`I can't see ${t.action} for ${t.item}.`, !0);
      }
      case "type_text": {
        const i = this.find(String(t.field), ["field"]);
        if (!i) return this.reply(`I can't see a box called ${t.field}.`, !0);
        X(i.el, this.panel.root);
        const n = B(i, String(t.text));
        return this.reply(`Typed “${n}” in ${i.name}`);
      }
      case "choose_option": {
        const i = this.find(String(t.list), ["select"]);
        if (!i) return this.reply(`I can't see a list called ${t.list}.`, !0);
        X(i.el, this.panel.root);
        const n = _e(i, String(t.option), K);
        return n ? this.reply(`${i.name}: ${n}`) : this.reply(`${i.name} has no ${t.option}.`, !0);
      }
      case "scroll_page":
        return ze(String(t.direction ?? "down")), this.reply(`Scrolled ${t.direction}`, !1, !1);
      case "read_aloud": {
        const i = Ve(String(t.part ?? "page"), this.panel.host);
        return this.panel.did(`Reading the ${t.part ?? "page"}`), this.say(i);
      }
      default: {
        const i = this.appTools[e.toolName];
        if (!i) return this.reply(`I don't know how to ${e.toolName}.`, !0);
        const n = typeof i.confirm == "function" ? i.confirm(t) : i.confirm ? e.toolName.replace(/_/g, " ") : !1;
        if (n && !e.confirmed) return this.ask(n, () => this.runCall({ ...e, confirmed: !0 }));
        try {
          const o = await i.execute(t), a = typeof o == "string" ? o : `Done: ${e.toolName.replace(/_/g, " ")}`;
          return this.reply(a);
        } catch (o) {
          return this.reply(`That didn't work: ${(o == null ? void 0 : o.message) ?? o}`, !0);
        }
      }
    }
  }
  ask(e, t) {
    return this.pending = { what: e, run: t, until: Date.now() + 2e4 }, this.handsFree && (this.awakeUntil = Date.now() + 2e4), this.reply(`${e}. Say yes to go ahead, or no.`);
  }
  risky(e) {
    var i;
    const t = (i = e.el.closest("[data-voice-confirm]")) == null ? void 0 : i.getAttribute("data-voice-confirm");
    return t ? t !== "false" : si.test(e.action ?? e.name) && e.kind !== "link" && e.kind !== "tab";
  }
  clickTarget(e, t = !1) {
    if (!t && this.risky(e))
      return X(e.el, this.panel.root), this.ask(e.item ? `${e.action} for ${e.item}` : e.name, () => this.clickTarget(e, !0));
    if (X(e.el, this.panel.root), e.kind === "secret")
      return e.el.focus(), this.reply("This is a password box. Use your password manager or a passkey; I won’t type passwords by voice.");
    if (e.kind === "field")
      return e.el.focus(), this.dictating = e, this.reply(`${e.name}. Say what to type, then “done”.`);
    const i = e.el.tagName === "A" && e.el.href && !e.el.href.includes("#");
    this.reply(i ? `Opening ${e.name}` : e.kind === "check" ? `${e.name}` : `Pressed ${e.name}`, !1, !i), Pt(e);
  }
  // Returns false when the phrase matched but nothing on the page fits it,
  // so the model gets a go.
  runQuick(e) {
    switch (e.do) {
      case "scroll":
        return ze(e.direction), this.reply(`Scrolled ${e.direction}`, !1, !1);
      case "read":
        return e.part === "headings" ? this.reply(this.reader.headings()) : e.part === "form" ? this.reply(Ve("form", this.panel.host)) : this.startReading(() => this.reader.readPage());
      case "section":
        return this.startReading(() => this.reader.readSection());
      case "resume":
        return this.startReading(() => this.reader.resume());
      case "move":
        return this.voice.loadNatural(), this.reader.move(e.what, e.dir).then((t) => t && this.reply(t, !0));
      case "where":
        return this.reply(this.reader.where());
      case "rate": {
        const t = this.reader.faster(e.dir);
        return x.set("rate", String(t)), this.reply(e.dir > 0 ? "Faster" : "Slower");
      }
      case "type": {
        const t = this.targets.filter((o) => o.kind === "field"), i = K(t, e.field);
        if (!i) return !1;
        X(i.el, this.panel.root);
        const n = B(i, e.text);
        return this.reply(`Typed “${n}” in ${i.name}`);
      }
      case "wake":
        return this.setWakeWord(e.word);
      case "pause": {
        const t = ["short", "medium", "long"], i = t.indexOf(x.get("pause") || "short"), n = t[Math.max(0, Math.min(2, i + e.dir))];
        return this.setPause(n);
      }
      case "narrate":
        return e.on ? (this.voice.loadNatural(), this.awakeUntil = 0, this.narrator.start().then((t) => t ? this.reply(t, !0) : this.panel.did("Narrating the video. Say “stop” to stop."))) : (this.hush(), this.panel.did("Stopped"));
      case "check": {
        const t = ti(this.panel.host);
        console.table(t.map(({ el: n, ...o }) => o)), ii(t);
        const i = t.filter((n) => n.el).map((n, o) => ({ num: o + 1, el: n.el, kind: "button", name: n.rule }));
        return i.length && this.panel.showNumbers(i), this.reply(ot(t));
      }
      case "settings":
        return this.minimize(!1), this.panel.openSettings(), this.reply("Settings are open.");
      case "yes": {
        const t = this.pending;
        return this.pending = void 0, !t || Date.now() > t.until ? this.reply("There is nothing waiting for a yes.", !0) : t.run();
      }
      case "no": {
        const t = this.pending;
        return this.pending = void 0, this.reply(t ? `OK, I won't. ${t.what} cancelled.` : "OK.");
      }
      case "undo":
      case "dropword": {
        const t = this.targets.find((o) => o.el === document.activeElement && o.kind === "field");
        if (!t) return this.reply("Nothing to delete: no box is selected.", !0);
        const i = t.el, n = e.do === "undo" ? Ot(i) : Ut(i.value);
        return n === null ? this.reply("There is nothing I typed to take back.", !0) : (Dt(t, n), this.reply(e.do === "undo" ? "Deleted" : "Deleted the last word"));
      }
      case "spell": {
        const t = Ct(e.text), i = this.targets.find((o) => o.el === document.activeElement && o.kind === "field");
        if (!t) return this.reply("Say the letters one by one, like “spell J O H N”.", !0);
        if (!i) return this.reply("Select a box first, then spell.", !0);
        const n = B(i, t, !0);
        return this.reply(`Typed ${n.split("").join(" ")}`);
      }
      case "stop":
        return this.panel.menuOpen && !this.talking ? this.runQuick({ do: "menu", act: "close" }) : (this.hush(), this.panel.did("Stopped"));
      case "sleep":
        return this.awakeUntil = 0, this.handsFree && this.mic.running ? (this.showState(), this.panel.status(this.idleStatus()), this.reply(`OK. Say “${R[0]}” when you need me.`)) : void 0;
      case "panel":
        return this.minimize(!e.open), this.reply(e.open ? "Voice control open. Say “minimize” to make it small." : "Made it small. Say “expand” to open it again.");
      case "off":
        return this.awakeUntil = 0, this.setHandsFree(!1), this.mic.stop(), this.showState(), this.reply("Stopped listening");
      case "help":
        return this.refresh(), this.panel.root.querySelector("details").open = !0, this.reply("Here is what you can say.");
      case "numbers":
        return this.numbers(e.on);
      case "drag":
        return this.panel.moveBy(e.dx, e.dy), this.reply("Moved", !1, !1);
      case "place":
        return this.panel.place(e.v, e.h), this.reply("Moved", !1, !1);
      case "menu":
        return e.act === "open" ? this.openMenu() : this.menu ? e.act === "close" ? (this.menu = void 0, this.panel.hideMenu(), this.reply("Menu closed")) : (this.menu.page = Math.max(0, this.menu.page + (e.act === "more" ? 1 : -1)), this.drawMenu()) : e.act === "close" ? this.runQuick({ do: "panel", open: !1 }) : this.reply("Say “menu” to see what you can do here.", !0);
      case "number": {
        if (this.menu && this.panel.menuOpen) return this.pickMenu(e.n);
        const t = this.targets.find((i) => i.num === e.n);
        return this.numbers(!1), t ? this.clickTarget(t) : this.reply(`There is no number ${e.n}.`, !0);
      }
      case "back":
        return this.reply("Going back", !1, !1), history.back();
      case "forward":
        return history.forward();
      case "reload":
        return location.reload();
      case "submit": {
        const t = jt(this.targets);
        return t ? this.clickTarget(t) : this.reply("There is no form to send here.", !0);
      }
      case "clear": {
        const t = this.targets.find((i) => i.el === document.activeElement && i.kind === "field");
        return t && B(t, ""), this.reply(t ? `Cleared ${t.name}` : "Nothing to clear.", !t);
      }
      case "newline": {
        const t = this.targets.find((i) => i.el === document.activeElement && i.kind === "field");
        t && t.el.tagName === "TEXTAREA" && B(t, t.el.value + `
`);
        return;
      }
    }
  }
  setWakeWord(e) {
    if (e = e.trim().toLowerCase(), !!e)
      return x.set("wake", e), rt(e), this.panel.setWake(e), this.refresh(), this.mic.running && this.handsFree && !this.awake && this.panel.status(this.idleStatus()), this.reply(`Wake word is now “${e}”.`);
  }
  setPause(e) {
    if (le[e])
      return x.set("pause", e), this.mic.quietBlocks = le[e], this.panel.setPause(e), this.reply(`${e[0].toUpperCase() + e.slice(1)} pause: I wait ${(le[e] * 0.02).toFixed(1)} seconds of quiet before acting.`);
  }
  onSwitch(e) {
    var o, a;
    const t = x.get("switchKey");
    if (!t || e.code !== t || e.repeat || ((a = (o = e.target) == null ? void 0 : o.closest) == null ? void 0 : a.call(o, "input,textarea,[contenteditable]")) && !this.panel.host.contains(e.target) && !x.get("scan")) return;
    if (e.preventDefault(), e.stopPropagation(), x.get("scan") !== "1") return void this.toggle();
    const n = Date.now();
    if (n - this.lastPress < 450) {
      clearTimeout(this.pressTimer), this.lastPress = 0;
      const r = this.targets[this.scanAt];
      this.panel.showNumbers(null), r && this.clickTarget(r);
      return;
    }
    this.lastPress = n, this.pressTimer = setTimeout(() => {
      if (this.targets = U(this.panel.host), !this.targets.length) return;
      this.scanAt = (this.scanAt + 1) % this.targets.length;
      const r = this.targets[this.scanAt];
      r.el.scrollIntoView({ block: "nearest" }), this.panel.showNumbers([r]), X(r.el, this.panel.root), this.panel.did(`${r.name}. Press twice to choose.`), this.say(r.name);
    }, 460);
  }
  // What can be done here, as a numbered list: things on screen first, then the
  // rest of the page, then general actions.
  openMenu() {
    this.targets = U(this.panel.host);
    const e = (n) => {
      const o = n.el.getBoundingClientRect();
      return o.bottom > 0 && o.top < innerHeight;
    }, t = [...this.targets.filter(e), ...this.targets.filter((n) => !e(n))], i = [];
    for (const n of t) {
      if (n.kind === "secret") continue;
      const o = n.el.checked || n.el.getAttribute("aria-checked") === "true", a = n.kind === "link" ? `Open ${n.name}` : n.kind === "field" ? `Type in ${n.name}` : n.kind === "select" ? `Choose ${n.name}` : n.kind === "check" ? `${o ? "Untick" : "Tick"} ${n.name}` : n.kind === "tab" ? `Show ${n.name}` : n.item ? `${n.action}: ${n.item}` : n.name, r = n.kind === "select" ? () => this.optionsMenu(n) : () => this.clickTarget(n);
      i.push({ label: a, run: r });
    }
    return i.push(
      { label: "Read the page aloud", run: () => this.runQuick({ do: "read", part: "page" }) },
      { label: "Scroll down", run: () => this.runQuick({ do: "scroll", direction: "down" }) },
      { label: "Go back", run: () => this.runQuick({ do: "back" }) }
    ), this.menu = { title: "What you can do here", items: i, page: 0 }, this.drawMenu();
  }
  optionsMenu(e) {
    const t = e.el, i = Array.from(t.options).map((n) => ({
      label: n.text,
      run: () => (_e(e, n.text, K), this.reply(`${e.name}: ${n.text}`))
    }));
    return this.menu = { title: `Choose ${e.name}`, items: i, page: 0 }, this.drawMenu();
  }
  drawMenu() {
    const e = this.menu, t = 9, i = Math.ceil(e.items.length / t);
    e.page = Math.min(e.page, i - 1);
    const n = e.page * t, o = e.items.slice(n, n + t), a = n + t < e.items.length, r = `Say a number${a ? ", “more” for more" : ""}${e.page ? ", “previous page” to go back" : ""}, or “close”.`;
    this.panel.showMenu(e.title + (i > 1 ? ` (${e.page + 1} of ${i})` : ""), o.map((c) => c.label), n + 1, r, a), this.handsFree && (this.awakeUntil = Date.now() + 3e4), this.panel.did(e.page ? "Next part of the menu" : "Menu open. Say a number."), this.say(e.page ? "Next part of the menu." : "Menu open. Say a number.");
  }
  pickMenu(e) {
    const t = this.menu, i = t == null ? void 0 : t.items[e - 1];
    return i ? (this.menu = void 0, this.panel.hideMenu(), i.run()) : this.reply(`There is no number ${e} in the menu.`, !0);
  }
  minimize(e) {
    this.panel.minimize(e), x.set("min", e ? "1" : "");
  }
  numbers(e) {
    this.targets = U(this.panel.host), this.panel.showNumbers(e ? this.targets : null), this.panel.did(e ? "Say a number" : "");
  }
  // Long reading: no follow-up window (only "computer, …" interrupts), and the
  // mic stays open so the wake word can be heard over the reading.
  startReading(e) {
    this.voice.loadNatural(), this.awakeUntil = 0, e();
  }
  reply(e, t = !1, i = !0) {
    this.panel.did(e, t), i && this.say(e);
  }
  // Our own voice: speech that began while we were making sound (plus the
  // echo's tail), or words that mostly repeat what we just said.
  isOwnVoice(e, t) {
    if (t && t >= this.talkStart - 300 && (t <= this.talkEnd + 400 || this.talkEnd < this.talkStart)) return !0;
    const i = new Set(this.recentSpeech.flatMap((o) => j(o.text))), n = j(e);
    return !n.length || !i.size ? !1 : n.filter((o) => i.has(o)).length / n.length >= 0.6;
  }
  get talking() {
    var e;
    return this.reader.reading || !!((e = this.narrator) != null && e.busy) || Date.now() < this.talkingUntil;
  }
  say(e) {
    this.speakOn && (this.reader.stop(), this.talkingUntil = Date.now() + 6e4, this.mic.maxBlocks = 200, this.voice.speak(e).finally(() => {
      this.talkingUntil = Date.now() + 400, setTimeout(() => !this.talking && (this.mic.maxBlocks = 750), 450);
    }));
  }
  hush() {
    this.narrator.stop(), this.reader.stop(), this.voice.stop(), this.talkingUntil = 0, this.mic.maxBlocks = 750;
  }
}
if (!window.voiceNav) {
  const s = new ai();
  window.voiceNav = s;
  for (const [e, t] of window.voiceNavQueue ?? []) s.register(e, t);
  dispatchEvent(new CustomEvent("voicenav:ready", { detail: s })), fe("voicenav-narrate") === "auto" && s.autoNarrate(), fe("voicenav-lazy") === "1" ? s.idle() : s.load();
}
function ci() {
  try {
    const s = new AudioContext(), e = s.createOscillator(), t = s.createGain();
    e.frequency.setValueAtTime(660, s.currentTime), e.frequency.linearRampToValueAtTime(990, s.currentTime + 0.12), t.gain.setValueAtTime(1e-4, s.currentTime), t.gain.exponentialRampToValueAtTime(0.2, s.currentTime + 0.02), t.gain.exponentialRampToValueAtTime(1e-4, s.currentTime + 0.25), e.connect(t).connect(s.destination), e.start(), e.stop(s.currentTime + 0.26), e.onended = () => s.close();
  } catch {
  }
}
