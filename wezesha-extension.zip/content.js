// Adds the Wezesha plugin to the page, unless it is switched off for this site
// or the site already has it.
(async () => {
  const { off = [] } = await chrome.storage.local.get('off');
  if (off.includes(location.hostname)) return;
  if (document.querySelector('voice-nav, script[src*="voicenav.js"]')) return;
  const s = document.createElement('script');
  s.type = 'module';
  // The plugin runs in the page; it finds worker.js and needle.wasm next to itself.
  s.src = chrome.runtime.getURL('voicenav.js');
  (document.head || document.documentElement).appendChild(s);
})();
